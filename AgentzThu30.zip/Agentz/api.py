from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from agentix import AgentiX
from agentix.types import AgentDefinition, UserRequest, ToolDefinition
from langchain_core.tools import BaseTool, Tool
from langchain_core.messages import BaseMessage, FunctionMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_openai_functions_agent
from langchain_core.prompts import PromptTemplate, ChatPromptTemplate, MessagesPlaceholder
from langgraph.graph import Graph, StateGraph, END
from typing_extensions import TypedDict
import uvicorn
import json
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Define AgentState type
class AgentState(TypedDict):
    """State of the agent system."""
    messages: List[BaseMessage]
    next_step: str

app = FastAPI(
    title="AgentiX API",
    description="API for using ReAct agents",
    version="0.1.0"
)

# Initialize AgentiX
agentix = AgentiX()

class AgentDetails(BaseModel):
    """Response model for agent details"""
    agent_name: str
    description: str
    tools: List[Dict[str, str]]
    example_code: str

class AgentRunRequest(BaseModel):
    """Request model for running an agent"""
    query: str

def get_tool_implementations(agent_def: AgentDefinition) -> List[Tool]:
    """Get actual tool implementations from the registry."""
    tools = []
    
    for tool_def in agent_def.tools:
        # Get implementation from registry
        impl = agentix.tool_registry.get_tool(tool_def.identifier)
        if impl:
            try:
                # Create a function that will execute the tool's code
                exec_globals = {
                    'Tool': Tool,
                    'BaseTool': BaseTool,
                    'ChatOpenAI': ChatOpenAI,
                    'PromptTemplate': PromptTemplate,
                    'os': os,
                    'json': json,
                    'requests': __import__('requests'),
                    'logging': logging
                }
                
                # Execute the tool code in our prepared environment
                exec(impl.code, exec_globals)
                
                # Find the tool class
                tool_class = None
                for var_name, var_value in exec_globals.items():
                    if isinstance(var_value, type):
                        if issubclass(var_value, BaseTool) and var_value != BaseTool:
                            tool_class = var_value
                            break
                        elif issubclass(var_value, Tool) and var_value != Tool:
                            tool_class = var_value
                            break
                
                if tool_class:
                    if issubclass(tool_class, BaseTool):
                        # Create a function that will be used as the tool's implementation
                        def create_run_func(tool_cls=tool_class):
                            def run_func(input_text: str) -> str:
                                instance = tool_cls(
                                    name=impl.name,
                                    description=impl.description
                                )
                                return instance._run(input_text)
                            return run_func
                        
                        # Create a Tool instance
                        tool = Tool(
                            name=impl.name,
                            description=impl.description,
                            func=create_run_func()
                        )
                    else:
                        # Create an instance of the Tool class directly
                        tool = tool_class(
                            name=impl.name,
                            description=impl.description,
                            func=lambda x: x  # Will be overridden by the class's own implementation
                        )
                    tools.append(tool)
                else:
                    raise ValueError(f"No valid tool class found for {tool_def.identifier}")
                
            except Exception as e:
                print(f"Error loading tool {tool_def.identifier}: {str(e)}")
                import traceback
                print(f"Traceback: {traceback.format_exc()}")
                continue
    
    return tools

@app.get("/agents", response_model=List[AgentDetails])
async def list_agents():
    """List all available agents."""
    try:
        agents = agentix.get_all_agents()
        return [
            AgentDetails(
                agent_name=agent.agent_name,
                description=agent.agent_description,
                tools=[
                    {
                        "name": tool.name,
                        "description": tool.description
                    }
                    for tool in agent.tools
                ],
                example_code=f"""
# Example usage of {agent.agent_name}
from agentix import AgentiX

# Initialize AgentiX
agentix = AgentiX()

# Get the agent
agents = agentix.search_agents("{agent.agent_name}")
if agents:
    agent = agents[0]
    # Create executor
    executor = agentix.create_agent_executor(agent)
    
    # Run the agent
    result = executor.invoke({{"input": "Your query here"}})
    print(result["output"])
"""
            )
            for agent in agents
        ]
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

@app.get("/agents/{agent_name}", response_model=AgentDetails)
async def get_agent(agent_name: str):
    """Get details of a specific agent."""
    try:
        agents = agentix.search_agents(agent_name)
        if not agents:
            raise HTTPException(
                status_code=404,
                detail=f"Agent {agent_name} not found"
            )
            
        agent = agents[0]
        return AgentDetails(
            agent_name=agent.agent_name,
            description=agent.agent_description,
            tools=[
                {
                    "name": tool.name,
                    "description": tool.description
                }
                for tool in agent.tools
            ],
            example_code=f"""
# Example usage of {agent.agent_name}
from agentix import AgentiX
            
# Initialize AgentiX
agentix = AgentiX()

# Get the agent
agents = agentix.search_agents("{agent.agent_name}")
if agents:
    agent = agents[0]
    # Create executor
    executor = agentix.create_agent_executor(agent)
    
    # Run the agent
    result = executor.invoke({{"input": "Your query here"}})
    print(result["output"])
"""
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

@app.post("/agents/{agent_name}/run")
async def run_agent(agent_name: str, request: AgentRunRequest):
    """Run a specific agent with a query."""
    try:
        # Find agent
        agents = agentix.search_agents(agent_name)
        if not agents:
            raise HTTPException(
                status_code=404,
                detail=f"Agent {agent_name} not found"
            )
            
        agent = agents[0]
            
        # Get tool implementations
        tools = get_tool_implementations(agent)
        if not tools:
            raise HTTPException(
                status_code=500,
                detail="No tool implementations found for this agent"
            )
        
        # Create LangGraph workflow
        workflow = create_agent_graph(tools, agent.agent_prompt)
        
        # Initialize state
        state = AgentState(
            messages=[HumanMessage(content=request.query)],
            next_step="agent"
        )
        
        # Run the workflow
        final_state = workflow.invoke(state)
        
        # Process the final state
        if final_state["messages"]:
            last_message = final_state["messages"][-1]
            if isinstance(last_message, FunctionMessage):
                try:
                    response_data = json.loads(last_message.content)
                    return {
                        "result": response_data.get("output", "No output"),
                        "intermediate_steps": response_data.get("intermediate_steps", []),
                        "chain_of_thought": response_data.get("chain_of_thought", [])
                    }
                except json.JSONDecodeError:
                    return {"result": last_message.content}
            else:
                return {"result": last_message.content}
        else:
            return {"result": "No response generated"}
            
    except Exception as e:
        logger.error(f"Error running agent {agent_name}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

def create_agent_graph(tools: List[Tool], system_prompt: str) -> Graph:
    """Create the LangGraph workflow for agent execution."""
    workflow = StateGraph(AgentState)
    
    # Initialize LLM with lower temperature and gpt-4o
    try:
        llm = ChatOpenAI(
            model="gpt-4o",
            temperature=0,
            max_tokens=1000
        )
    except Exception as e:
        raise ValueError(f"Failed to initialize LLM: {str(e)}")

    # Create the agent with tools
    prompt = ChatPromptTemplate.from_messages([
        ("system", f"{system_prompt}\n\nWhen using tools, always follow this format:\nThought: Think about what to do\nAction: tool_name\nAction Input: input to the tool\nObservation: tool output\nThought: Think about what the output means\n... (repeat as needed)\nFinal Answer: The final response when task is complete"),
        MessagesPlaceholder(variable_name="chat_history"),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad")
    ])
    
    # Create the agent
    agent = create_openai_functions_agent(llm, tools, prompt)
    
    # Create the agent executor with proper configuration
    agent_executor = AgentExecutor(
        agent=agent,
        tools=tools,
        handle_parsing_errors=True,
        max_iterations=5,
        early_stopping_method="force",
        verbose=True,
        return_intermediate_steps=True
    )
    
    def should_continue(state: AgentState) -> str:
        """Determine if we should continue or stop."""
        messages = state["messages"]
        if not messages:
            return "continue"
            
        last_message = messages[-1]
        
        # If it's a function message containing a final answer, stop
        if isinstance(last_message, FunctionMessage):
            try:
                content = json.loads(last_message.content)
                if "output" in content:
                    output = content["output"]
                    if "Final Answer:" in output:
                        return "end"
                    if not content.get("intermediate_steps"):
                        return "end"
            except:
                pass
        
        # If we've hit our iteration limit (5 iterations), stop
        if len([m for m in messages if isinstance(m, FunctionMessage)]) >= 5:
            return "end"
            
        return "continue"
    
    def agent_node(state: AgentState) -> AgentState:
        """Process the agent's response."""
        try:
            # Get the last message
            last_message = state["messages"][-1]
            
            try:
                # Run the agent executor
                result = agent_executor.invoke({
                    "input": last_message.content,
                    "chat_history": state["messages"][:-1]
                })
                
                # Convert intermediate steps to serializable format
                serializable_steps = []
                chain_of_thought = []
                
                # Process intermediate steps and build chain of thought
                for step in result.get("intermediate_steps", []):
                    if isinstance(step, tuple) and len(step) == 2:
                        action, observation = step
                        # Add to serializable steps
                        serializable_steps.append({
                            "action": {
                                "tool": action.tool,
                                "tool_input": action.tool_input,
                                "log": action.log
                            },
                            "observation": observation
                        })
                        
                        # Add to chain of thought
                        if action.log:
                            chain_of_thought.append({
                                "type": "thought",
                                "content": action.log
                            })
                        chain_of_thought.append({
                            "type": "action",
                            "tool": action.tool,
                            "input": action.tool_input
                        })
                        chain_of_thought.append({
                            "type": "observation",
                            "content": observation
                        })
                
                # Extract final answer if present
                output = result["output"]
                if "Final Answer:" in output:
                    # Extract just the final answer part
                    final_answer = output.split("Final Answer:")[-1].strip()
                    chain_of_thought.append({
                        "type": "final_answer",
                        "content": final_answer
                    })
                else:
                    final_answer = output
                
                # Convert result to a serializable format
                serializable_response = {
                    "output": final_answer,
                    "intermediate_steps": serializable_steps,
                    "chain_of_thought": chain_of_thought
                }
                
            finally:
                pass
            
            # Add response to messages
            state["messages"].append(FunctionMessage(
                name="agent",
                content=json.dumps(serializable_response)
            ))
            
            return state
            
        except Exception as e:
            logger.error(f"Agent error: {str(e)}")
            import traceback
            logger.error(f"Traceback: {traceback.format_exc()}")
            state["messages"].append(FunctionMessage(
                name="error",
                content=str(e)
            ))
            return state
    
    # Add nodes
    workflow.add_node("agent", agent_node)
    
    # Add edges
    workflow.add_conditional_edges(
        "agent",
        should_continue,
        {
            "continue": "agent",
            "end": END
        }
    )
    
    # Set entry point
    workflow.set_entry_point("agent")
    
    return workflow.compile()

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000) 