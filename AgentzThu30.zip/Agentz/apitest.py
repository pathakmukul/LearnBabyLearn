import requests

def print_separator():
    print("\n" + "="*50 + "\n")

# 1. List all available agents
print("Getting list of available agents...")
response = requests.get("http://localhost:8000/agents")
if response.status_code == 200:
    agents = response.json()
    print(f"Found {len(agents)} agents:")
    for agent in agents:
        print(f"\nAgent: {agent['agent_name']}")
        print(f"Description: {agent['description']}")
        print(f"Available Tools:")
        for tool in agent['tools']:
            print(f"  - {tool['name']}: {tool['description']}")
else:
    print(f"Error getting agents: {response.text}")

print_separator()

# 2. Get details of a specific agent (using first agent from the list)
if response.status_code == 200 and agents:
    first_agent = agents[0]
    print(f"Getting details for agent: {first_agent['agent_name']}")
    response = requests.get(f"http://localhost:8000/agents/{first_agent['agent_name']}")
    if response.status_code == 200:
        agent_details = response.json()
        print("\nExample code to use this agent:")
        print(agent_details['example_code'])
    else:
        print(f"Error getting agent details: {response.text}")

    print_separator()

    # 3. Run the agent
    print(f"Running agent: {first_agent['agent_name']}")
    response = requests.post(
        f"http://localhost:8000/agents/{first_agent['agent_name']}/run",
        json={"query": "I am at the zoo."}
    )
    if response.status_code == 200:
        result = response.json()
        print("\nAgent Response:")
        print(result['result'])
        print("\nIntermediate Steps:")
        for step in result.get('intermediate_steps', []):
            print(f"  - {step}")
    else:
        print(f"Error running agent: {response.text}") 