import streamlit as st
from agentix.core import AgentiX
from agentix.types import UserRequest
from agentix.graph_agent import AgentState
from typing import Dict, Any, List
from langchain_core.messages import BaseMessage
from pages.resources import show_resources_page
from pages.playground import show_playground_page
import json

def display_react_process(msg):
    """Display a ReAct thinking process step."""
    try:
        content = json.loads(msg.content)
        if all(k in content for k in ["thought", "action", "action_input"]):
            st.markdown(f"🤔 {content['thought']}")
            return True
    except:
        pass
    return False

def display_messages(messages):
    """Display message history in a structured way."""
    for msg in messages:
        if msg.type == "human":
            st.markdown(f"🧑‍💻 {msg.content}")
        elif msg.type == "function":
            # Try to display as ReAct process first
            if not display_react_process(msg):
                try:
                    content = json.loads(msg.content)
                    if "thought" in content:
                        st.markdown(f"🤖 {content['thought']}")
                    elif "output" in content:
                        st.markdown(f"🤖 {content['output']}")
                except:
                    st.markdown(f"🤖 {msg.content}")
        else:
            st.markdown(f"🤖 {msg.content}")

def get_messages_for_stage(chunk: dict, stage: str) -> List[BaseMessage]:
    """Extract messages for a specific stage from the chunk."""
    if "messages" not in chunk:
        return []
    return [m for m in chunk["messages"] if stage in str(m.content)]

def show_create_agent_page():
    """Show the create agent page."""
    st.title("Create/Find Agent")
    st.write("""
    Welcome to AgentiX! This tool helps you create and manage ReAct agents using LangGraph.
    Simply describe what you want your agent to do, and we'll either find an existing agent
    or create a new one for you.
    """)
    
    # Initialize AgentiX
    agentix = AgentiX()
    
    # Get user input
    description = st.text_area(
        "Describe what you want your agent to do:",
        height=100,
        placeholder="E.g., I want an agent that can scrape product prices from websites and compare them"
    )
    
    requirements = st.text_area(
        "List any specific requirements (one per line):",
        height=100,
        placeholder="E.g.,\nMust be able to handle multiple URLs\nShould compare prices accurately\nNeeds to handle different currencies"
    )
    
    if st.button("Create/Find Agent"):
        if not description:
            st.error("Please provide a description of what you want your agent to do.")
            return
            
        # Create user request
        request = UserRequest(
            description=description,
            requirements=requirements.split("\n") if requirements.strip() else []
        )
        
        # Create containers for workflow visualization
        workflow_container = st.container()
        with workflow_container:
            st.markdown("### 🔄 Creating Your Agent")
            
            progress_text = st.empty()
            progress_bar = st.progress(0)
            
            try:
                # Initialize workflow state
                state = AgentState(
                    messages=[],
                    user_request=request,
                    current_tools=[],
                    agent_definition=None,
                    next_step="analyze_requirements"
                )
                
                # Execute workflow with state tracking
                for i, chunk in enumerate(agentix.graph.stream_process(state)):
                    # Update progress
                    progress = (i + 1) * 33 if i < 2 else 100  # 3 steps total
                    progress_bar.progress(progress)
                    
                    # Update status text based on step
                    if chunk["next_step"] == "analyze_requirements":
                        progress_text.info("🔍 Analyzing your requirements...")
                    elif chunk["next_step"] == "search_existing":
                        progress_text.info("🔍 Searching for existing agents...")
                    elif chunk["next_step"] == "create_agent":
                        progress_text.info("🛠️ Creating your agent...")
                    elif chunk["next_step"] == "end":
                        progress_text.success("✅ Agent ready!")
                
                # Get final agent definition
                agent_def = chunk.get("agent_definition")
                
                if agent_def is None:
                    st.error("Failed to create or find an agent. Please try again.")
                    return
                
                # Show success message
                is_new_agent = agent_def.agent_name.startswith("agent_")
                st.success(f"{'Created' if is_new_agent else 'Found'} agent: {agent_def.agent_name}")
                
                # Show agent details in an expander
                with st.expander("📋 Agent Details", expanded=True):
                    st.markdown(f"**Description:** {agent_def.agent_description}")
                    st.markdown("**Tools:**")
                    for tool in agent_def.tools:
                        st.markdown(f"- **{tool.name}**: {tool.description}")
                
                # Show generated code
                with st.expander("💻 Generated Code", expanded=False):
                    code = agentix.get_agent_code(agent_def)
                    st.code(code, language="python")
                    
                    st.download_button(
                        label="📥 Download Code",
                        data=code,
                        file_name=f"{agent_def.agent_name}.py",
                        mime="text/plain"
                    )
                
                # Add usage example
                with st.expander("📚 Usage Example", expanded=False):
                    st.markdown("""
                    ### How to use this agent:
                    
                    1. **Save the code** above to a Python file (e.g., `agent.py`)
                    2. **Install requirements** if not already installed:
                       ```bash
                       pip install langchain langchain-openai python-dotenv
                       ```
                    3. **Set up environment variables** in a `.env` file:
                       ```
                       OPENAI_API_KEY=your-api-key-here
                       ```
                    4. **Run the agent**:
                       ```python
                       response = agent.run("Your query here")
                       print(response)
                       ```
                    """)
            
            except Exception as e:
                st.error(f"Error during workflow execution: {str(e)}")
                raise e

def main():
    st.set_page_config(
        page_title="AgentiX",
        page_icon="🤖",
        layout="wide"
    )
    
    # Create sidebar navigation
    page = st.sidebar.selectbox(
        "Select Page",
        ["Create/Find Agent", "Available Resources", "🎮 Playground"]
    )
    
    # Show selected page
    if page == "Create/Find Agent":
        show_create_agent_page()
    elif page == "Available Resources":
        show_resources_page()
    else:
        show_playground_page()

if __name__ == "__main__":
    main() 