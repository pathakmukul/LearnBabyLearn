from typing import Dict, List, Optional, Any
from pydantic import BaseModel
import json
import os
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
import importlib
import pytest
import tempfile
import logging

class ToolCategory(BaseModel):
    """Category for organizing tools."""
    name: str
    description: str
    parent: Optional[str] = None

class ToolImplementation(BaseModel):
    """Represents a tool's implementation."""
    name: str
    description: str
    code: str
    identifier: str
    dependencies: List[str]
    version: str
    category: str
    test_cases: List[Dict[str, Any]] = []
    metadata: Dict[str, Any] = {}

class ToolSpecification(BaseModel):
    """Specification for a tool before implementation."""
    name: str
    description: str
    input_params: List[Dict[str, str]]  # [{"name": "param1", "type": "str", "description": "..."}]
    output_type: str
    required_capabilities: List[str]
    example_usage: str

class ToolRegistry:
    """Registry for managing and generating tool implementations."""
    
    def __init__(self, llm: ChatOpenAI, storage_path: str = "tools_registry.json"):
        """Initialize the tool registry."""
        self.llm = llm
        self.storage_path = storage_path if storage_path else "tools_registry.json"
        self.tools: Dict[str, ToolImplementation] = {}
        self.categories: Dict[str, ToolCategory] = {}
        self.logger = logging.getLogger("tool_registry")
        
        # Load existing registry if it exists
        self._load_registry()
    
    def _setup_logging(self):
        """Setup logging for the tool registry."""
        self.logger = logging.getLogger("tool_registry")
        self.logger.setLevel(logging.INFO)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
    
    def _load_registry(self):
        """Load the tool registry from storage."""
        try:
            if os.path.exists(self.storage_path):
                with open(self.storage_path, 'r') as f:
                    data = json.load(f)
                    self.tools = {
                        name: ToolImplementation(**impl) 
                        for name, impl in data.get("tools", {}).items()
                    }
                    self.categories = {
                        name: ToolCategory(**cat)
                        for name, cat in data.get("categories", {}).items()
                    }
                    self.logger.info(f"Successfully loaded registry from {self.storage_path}")
            else:
                self.tools = {}
                self._initialize_default_categories()
                self.logger.warning(f"Registry file not found at {self.storage_path}, initialized empty registry")
        except Exception as e:
            self.logger.error(f"Error loading registry: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            self.tools = {}
            self._initialize_default_categories()
    
    def _initialize_default_categories(self):
        """Initialize default tool categories."""
        default_categories = [
            ToolCategory(
                name="io",
                description="Input/Output operations like file handling"
            ),
            ToolCategory(
                name="api",
                description="API interaction tools"
            ),
            ToolCategory(
                name="processing",
                description="Data processing and transformation tools"
            ),
            ToolCategory(
                name="utility",
                description="Utility and helper tools"
            )
        ]
        for cat in default_categories:
            self.categories[cat.name] = cat
    
    def _save_registry(self):
        """Save the tool registry to storage."""
        try:
            # If storage_path is empty or None, use default
            if not self.storage_path:
                self.storage_path = "tools_registry.json"
                
            # Get directory path
            dir_path = os.path.dirname(os.path.abspath(self.storage_path))
            
            # Create directory if it doesn't exist
            if dir_path:
                os.makedirs(dir_path, exist_ok=True)
            
            # Save registry
            with open(self.storage_path, 'w') as f:
                json.dump({
                    "tools": {name: tool.model_dump() for name, tool in self.tools.items()},
                    "categories": {name: cat.model_dump() for name, cat in self.categories.items()}
                }, f, indent=2)
            self.logger.info(f"Successfully saved registry to {self.storage_path}")
        except Exception as e:
            self.logger.error(f"Error saving registry: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
    
    def _generate_test_cases(self, tool_impl: ToolImplementation) -> List[Dict[str, Any]]:
        """Generate test cases for a tool implementation."""
        prompt = f"""Generate test cases for this LangChain tool:

{tool_impl.code}

Return a JSON array of test cases, where each test case has:
1. input: The input parameters
2. expected_output: Expected output or behavior
3. description: What the test verifies

Example:
[
    {{
        "input": {{"url": "https://example.com"}},
        "expected_output": "HTML content",
        "description": "Verify basic URL fetch"
    }}
]"""
        
        response = self.llm.invoke([HumanMessage(content=prompt)])
        return json.loads(response.content)
    
    def _validate_tool_implementation(self, tool_impl: ToolImplementation) -> bool:
        """Validate a tool implementation through testing."""
        self.logger.info(f"Starting validation for tool: {tool_impl.name}")
        
        try:
            # First, check if the code contains required elements
            required_imports = [
                "from langchain_core.tools import BaseTool",
                "import logging"
            ]
            for imp in required_imports:
                if imp not in tool_impl.code:
                    self.logger.error(f"Missing required import: {imp}")
                    return False
            
            # Check for class definition
            if "class" not in tool_impl.code:
                self.logger.error("No class definition found")
                return False
            
            # Check for _run method
            if "def _run" not in tool_impl.code:
                self.logger.error("No _run method found")
                return False
            
            # Create a temporary module with the tool code
            with tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False) as f:
                self.logger.debug(f"Creating temporary file for validation: {f.name}")
                
                # Add necessary imports at the top
                imports = """from langchain_core.tools import BaseTool
import logging
from typing import Optional, Any

class CustomBaseTool(BaseTool):
    def _run(self, *args: Any, **kwargs: Any) -> str:
        raise NotImplementedError()
"""
                # Write imports and tool code
                f.write(imports + "\n" + tool_impl.code.replace("(BaseTool)", "(CustomBaseTool)"))
                f.flush()
                
                try:
                    # Import the temporary module
                    self.logger.debug("Attempting to import temporary module")
                    spec = importlib.util.spec_from_file_location(
                        "tool_module", f.name
                    )
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    
                    # Find the tool class
                    self.logger.debug("Searching for tool class in module")
                    tool_class = None
                    for attr in dir(module):
                        obj = getattr(module, attr)
                        if isinstance(obj, type) and issubclass(obj, module.CustomBaseTool) and obj != module.CustomBaseTool:
                            tool_class = obj
                            self.logger.info(f"Found tool class: {obj.__name__}")
                            break
                    
                    if not tool_class:
                        self.logger.error("No valid tool class found")
                        return False
                    
                    # Create an instance and validate
                    tool_instance = tool_class()
                    
                    # Validate name and description
                    if tool_instance.name != tool_impl.name:
                        self.logger.error(f"Tool name mismatch: {tool_instance.name} != {tool_impl.name}")
                        return False
                    
                    # For description, do a more lenient comparison
                    instance_desc = tool_instance.description.lower().strip()
                    impl_desc = tool_impl.description.lower().strip()
                    if not (instance_desc in impl_desc or impl_desc in instance_desc):
                        self.logger.error(f"Tool description mismatch: {instance_desc} vs {impl_desc}")
                        return False
                    
                    # Try to run the tool with test input
                    try:
                        # All tools should accept a single string input for simplicity
                        result = tool_instance._run("test input")
                        
                        if not isinstance(result, str):
                            self.logger.error("Tool _run method did not return a string")
                            return False
                            
                    except Exception as e:
                        self.logger.error(f"Tool execution test failed: {str(e)}")
                        return False
                    
                    self.logger.info(f"Tool {tool_impl.name} validation successful")
                    return True
                    
                except Exception as e:
                    self.logger.error(f"Validation failed: {str(e)}")
                    import traceback
                    self.logger.error(f"Traceback: {traceback.format_exc()}")
                    return False
                finally:
                    # Clean up the temporary file
                    try:
                        os.unlink(f.name)
                    except:
                        pass
                
        except Exception as e:
            self.logger.error(f"Validation failed: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            return False
    
    def generate_tool_implementation(self, name: str, description: str) -> Optional[ToolImplementation]:
        """Generate a tool implementation using a staged approach."""
        self.logger.info(f"Starting tool generation for: {name}")
        
        try:
            # Stage 1: Generate Tool Specification
            self.logger.info("Stage 1: Generating tool specification")
            spec = self._generate_tool_specification(name, description)
            if not spec:
                self.logger.error("Failed to generate tool specification")
                return None
            
            # Stage 2: Validate Specification
            self.logger.info("Stage 2: Validating specification")
            if not self._validate_tool_specification(spec):
                self.logger.error("Tool specification validation failed")
                return None
            
            # Stage 3: Generate Implementation
            self.logger.info("Stage 3: Generating implementation")
            code = self._generate_implementation_from_spec(spec)
            if not code:
                self.logger.error("Failed to generate implementation from spec")
                return None
            
            # Create tool implementation
            self.logger.info("Stage 4: Creating tool implementation")
            tool_impl = ToolImplementation(
                name=spec.name,
                description=spec.description,
                code=code,
                identifier=spec.name.lower().replace(' ', '_'),
                dependencies=["langchain_core"],
                version="1.0.0",
                category=self._determine_category(spec.description)
            )
            
            # Stage 5: Validate Implementation
            self.logger.info("Stage 5: Validating implementation")
            validation_result = self._validate_tool_implementation(tool_impl)
            
            if not validation_result:
                self.logger.error("Tool implementation validation failed")
                return None
            
            # Stage 6: Register the tool
            self.logger.info("Stage 6: Registering tool")
            if not self.register_tool(tool_impl):
                self.logger.error("Tool registration failed")
                return None
            
            self.logger.info(f"Successfully generated and registered tool: {name}")
            return tool_impl
            
        except Exception as e:
            self.logger.error(f"Error in tool generation pipeline: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            return None

    def _generate_tool_specification(self, name: str, description: str) -> Optional[ToolSpecification]:
        """Generate a tool specification from name and description."""
        prompt = f"""Create a detailed tool specification in JSON format.

Tool Name: {name}
Tool Description: {description}

The specification must include:
1. name: Exact tool name as provided
2. description: Detailed description of the tool's purpose
3. input_params: Array of input parameters. IMPORTANT: Tools should only accept a single 'input_text' parameter of type 'str'
4. output_type: Expected return type (must be 'str')
5. required_capabilities: Array of required capabilities or dependencies
6. example_usage: A concrete example showing how to use the tool

Return ONLY a valid JSON object like this:
{{
    "name": "{name}",
    "description": "Detailed description here",
    "input_params": [
        {{"name": "input_text", "type": "str", "description": "The input text to process"}}
    ],
    "output_type": "str",
    "required_capabilities": ["capability1", "capability2"],
    "example_usage": "tool.run('example input')"
}}

IMPORTANT: 
1. ALL tools must follow this exact input parameter structure
2. The output_type must ALWAYS be 'str'
3. Keep the implementation simple and focused on the core functionality

Return ONLY the JSON object, no other text or explanation."""

        try:
            # Get response from LLM
            response = self.llm.invoke(prompt)
            
            # Extract content from AIMessage
            if hasattr(response, 'content'):
                response_text = response.content
            else:
                response_text = str(response)
            
            # Clean the response text
            response_text = response_text.strip()
            if response_text.startswith("```json"):
                response_text = response_text.split("```json")[1]
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            response_text = response_text.strip()
            
            # Log the cleaned response for debugging
            self.logger.debug(f"Cleaned response text: {response_text}")
            
            try:
                # Parse JSON
                spec_dict = json.loads(response_text)
                
                # Validate required fields
                required_fields = ["name", "description", "input_params", 
                                 "output_type", "required_capabilities", 
                                 "example_usage"]
                for field in required_fields:
                    if field not in spec_dict:
                        raise ValueError(f"Missing required field: {field}")
                
                # Create and return specification
                return ToolSpecification(**spec_dict)
                
            except json.JSONDecodeError as e:
                self.logger.error(f"Failed to parse JSON: {str(e)}")
                self.logger.error(f"Response text was: {response_text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error generating specification: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            return None

    def _validate_tool_specification(self, spec: ToolSpecification) -> bool:
        """Validate a tool specification."""
        try:
            # Check name and description
            if not spec.name or not spec.description:
                self.logger.error("Missing name or description")
                return False
            
            # Validate input parameters
            for param in spec.input_params:
                if not all(k in param for k in ["name", "type", "description"]):
                    self.logger.error(f"Invalid parameter specification: {param}")
                    return False
                
            # Validate output type
            valid_types = ["str"]
            if spec.output_type not in valid_types:
                self.logger.error(f"Invalid output type: {spec.output_type}")
                return False
            
            # Validate example usage
            if not spec.example_usage or len(spec.example_usage) < 10:
                self.logger.error("Invalid or too short example usage")
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error validating specification: {str(e)}")
            return False

    def _generate_implementation_from_spec(self, spec: ToolSpecification) -> Optional[str]:
        """Generate implementation code from a validated specification."""
        prompt = f"""Create a LangChain tool implementation based on this specification:

{json.dumps(spec.model_dump(), indent=2)}

The implementation MUST start with these exact imports:
from langchain_core.tools import BaseTool
import logging
from typing import Optional, Any

The class MUST:
1. Inherit from BaseTool
2. Include these EXACT class attributes with type annotations:
   name: str = "{spec.name}"
   description: str = "{spec.description}"
3. Implement _run method with proper type hints
4. Include comprehensive error handling and logging
5. Return {spec.output_type} type as specified
6. Follow the example usage pattern: {spec.example_usage}

Example structure:
```python
from langchain_core.tools import BaseTool
import logging
from typing import Optional, Any

class ExampleTool(BaseTool):
    name: str = "example_tool"
    description: str = "Example tool description"
    
    def _run(self, input_text: str) -> str:
        logging.info("Running tool with input: {{input_text}}")
        try:
            # Implementation here
            result = "Processed: {{input_text}}"
            logging.info("Tool execution successful: {{result}}")
            return result
        except Exception as e:
            logging.error("Tool execution failed: {{str(e)}}")
            raise
```

IMPORTANT: 
1. The name and description MUST be EXACTLY as specified above with type annotations
2. The class MUST inherit from BaseTool
3. The _run method MUST include proper error handling and logging

Return ONLY the implementation code, no explanations."""

        try:
            # Get response from LLM
            response = self.llm.invoke(prompt)
            
            # Extract content from AIMessage
            if hasattr(response, 'content'):
                response_text = response.content
            else:
                response_text = str(response)
            
            # Clean the response text
            response_text = response_text.strip()
            if response_text.startswith("```python"):
                response_text = response_text.split("```python")[1]
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            response_text = response_text.strip()
            
            # Log the cleaned response for debugging
            self.logger.debug(f"Generated code:\n{response_text}")
            
            # Validate basic requirements
            required_elements = [
                "from langchain_core.tools import BaseTool",
                "import logging",
                "from typing import",
                "class",
                "BaseTool",
                "def _run",
                f'name: str = "{spec.name}"',
                f'description: str = "{spec.description}"'
            ]
            
            missing_elements = [elem for elem in required_elements if elem not in response_text]
            if missing_elements:
                self.logger.error(f"Generated code missing required elements: {missing_elements}")
                return None
            
            return response_text
            
        except Exception as e:
            self.logger.error(f"Error generating implementation: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            return None

    def _get_implementation_hints(self, name: str) -> str:
        """Get implementation hints based on tool requirements."""
        # Generic implementation hints that apply to all tools
        return """
- Implement proper error handling with try/except blocks
- Add comprehensive logging using the logging module
- Validate all inputs before processing
- Return consistent string output format
- Include type hints for all methods and parameters
- Add clear docstrings explaining functionality
- Handle edge cases gracefully
- Follow SOLID principles
- Keep the implementation focused and single-purpose
"""

    def _get_example_code(self, name: str) -> str:
        """Get a generic example code template for tool implementation."""
        return '''from langchain_core.tools import BaseTool
import logging
from typing import Optional, Any

class CustomTool(BaseTool):
    """Template for a custom LangChain tool.
    
    Attributes:
        name (str): The name of the tool
        description (str): A description of what the tool does
    """
    name: str = "custom_tool_name"
    description: str = "Description of what this tool does"
    
    def _run(self, *args: Any, **kwargs: Any) -> str:
        """Execute the tool's main functionality.
        
        Args:
            *args: Variable length argument list
            **kwargs: Arbitrary keyword arguments
            
        Returns:
            str: The result of the tool's execution
            
        Raises:
            ValueError: If inputs are invalid
            Exception: For any other errors during execution
        """
        logging.info(f"Running tool with args: {args}, kwargs: {kwargs}")
        
        try:
            # Validate inputs
            if not args and not kwargs:
                msg = "No inputs provided"
                logging.error(msg)
                raise ValueError(msg)
                
            # Process inputs and generate result
            # TODO: Implement actual tool logic here
            result = f"Processed input: {args}, {kwargs}"
            
            logging.info(f"Tool execution successful: {result}")
            return result
            
        except Exception as e:
            logging.error(f"Tool execution failed: {str(e)}")
            raise
'''

    def _extract_code(self, response: str) -> Optional[str]:
        """Extract code from LLM response."""
        try:
            # Get content from AIMessage
            if hasattr(response, 'content'):
                response_text = response.content
            else:
                response_text = str(response)
            
            # Clean the response text
            response_text = response_text.strip()
            if response_text.startswith("```python"):
                response_text = response_text.split("```python")[1]
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            response_text = response_text.strip()
            
            # Basic validation
            if not response_text or len(response_text) < 50:  # Arbitrary minimum length
                self.logger.warning("Extracted code too short or empty")
                return None
            
            if "class" not in response_text or "BaseTool" not in response_text:
                self.logger.warning("Extracted code missing required elements")
                return None
            
            return response_text
            
        except Exception as e:
            self.logger.error(f"Error extracting code: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            return None
    
    def register_tool(self, tool: ToolImplementation) -> bool:
        """Register a new tool in the registry."""
        try:
            # Validate tool
            if not self._validate_tool_implementation(tool):
                return False
            
            # Add to registry
            self.tools[tool.identifier] = tool
            self._save_registry()
            self.logger.info(f"Successfully registered tool: {tool.name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error registering tool {tool.name}: {str(e)}")
            return False

    def get_tool(self, identifier: str) -> Optional[ToolImplementation]:
        """Get a tool by its identifier."""
        tool = self.tools.get(identifier)
        if tool and not self._validate_dependencies(tool):
            self.logger.warning(
                f"Tool {tool.name} is missing dependencies: {', '.join(tool.dependencies)}"
            )
            return None
        return tool
    
    def search_tools(
        self, 
        query: str = "", 
        category: Optional[str] = None
    ) -> List[ToolImplementation]:
        """Search for tools based on name, description, or category."""
        query = query.lower()
        tools = self.tools.values()
        
        if category:
            tools = [t for t in tools if t.category == category]
            
        if query:
            tools = [
                t for t in tools
                if query in t.name.lower() or query in t.description.lower()
            ]
            
        return list(tools)
    
    def get_category_tools(self, category: str) -> List[ToolImplementation]:
        """Get all tools in a category."""
        return [t for t in self.tools.values() if t.category == category]
    
    def add_category(self, name: str, description: str, parent: Optional[str] = None):
        """Add a new tool category."""
        if parent and parent not in self.categories:
            raise ValueError(f"Parent category {parent} does not exist")
            
        self.categories[name] = ToolCategory(
            name=name,
            description=description,
            parent=parent
        )
        self._save_registry()
    
    def get_tool_dependencies(self, identifier: str) -> List[str]:
        """Get all dependencies for a tool."""
        tool = self.get_tool(identifier)
        return tool.dependencies if tool else []
    
    def update_tool(
        self, 
        identifier: str, 
        code: Optional[str] = None,
        description: Optional[str] = None,
        category: Optional[str] = None
    ) -> bool:
        """Update an existing tool."""
        if identifier not in self.tools:
            return False
            
        tool = self.tools[identifier]
        
        if code:
            tool.code = code
            # Regenerate test cases if code changes
            tool.test_cases = self._generate_test_cases(tool)
            
        if description:
            tool.description = description
            
        if category and category in self.categories:
            tool.category = category
            
        # Validate after updates
        if not self._validate_tool_implementation(tool):
            return False
            
            self._save_registry()
        return True
    
    def test_tool_creation(self, name: str, description: str) -> bool:
        """Test create a tool and verify it works."""
        self.logger.info(f"Testing tool creation for: {name}")
        
        try:
            # Determine category based on description
            category = self._determine_category(description)
            self.logger.info(f"Determined category: {category}")
            
            # Generate tool
            tool = self.generate_tool_implementation(
                name=name,
                description=description,
                category=category,
                requirements=[]
            )
            
            if not tool:
                self.logger.error("Tool generation failed")
                return False
            
            # Try to register it
            if not self.register_tool(tool):
                self.logger.error("Tool registration failed")
                return False
            
            self.logger.info("Tool creation test successful")
            return True
            
        except Exception as e:
            self.logger.error(f"Tool creation test failed: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
        return False
            
    def _determine_category(self, description: str) -> str:
        """Determine the appropriate category for a tool."""
        description = description.lower()
        
        if any(word in description for word in ["api", "fetch", "http", "request", "endpoint"]):
            return "api"
        elif any(word in description for word in ["file", "read", "write", "save", "load"]):
            return "io"
        elif any(word in description for word in ["process", "transform", "convert", "analyze"]):
            return "processing"
        else:
            return "utility"

    def _validate_dependencies(self, tool: ToolImplementation) -> bool:
        """Validate that all dependencies for a tool are available."""
        try:
            # For now, we'll just return True as we're not actually checking dependencies
            # In a real implementation, you would check if all required packages are installed
            return True
        except Exception as e:
            self.logger.error(f"Error validating dependencies: {str(e)}")
            return False