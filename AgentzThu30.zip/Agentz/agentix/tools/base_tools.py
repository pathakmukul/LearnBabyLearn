from typing import Any, Dict, Optional
from langchain_core.tools import BaseTool
import requests
import json
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class APIRequestTool(BaseTool):
    """Tool for making API requests."""
    
    name = "api_request"
    description = "Make HTTP requests to APIs"
    
    def _run(self, url: str, method: str = "GET", headers: Optional[Dict] = None, data: Optional[Dict] = None) -> str:
        """Execute the API request."""
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=headers or {},
                json=data if method in ["POST", "PUT", "PATCH"] else None
            )
            return response.text
        except Exception as e:
            return f"Error making API request: {str(e)}"

class FileOperationTool(BaseTool):
    """Tool for file operations."""
    
    name = "file_operation"
    description = "Read from or write to files"
    
    def _run(self, operation: str, path: str, content: Optional[str] = None) -> str:
        """Execute the file operation."""
        try:
            if operation.lower() == "read":
                with open(path, 'r') as f:
                    return f.read()
            elif operation.lower() == "write":
                if content is None:
                    return "Error: Content is required for write operation"
                with open(path, 'w') as f:
                    f.write(content)
                return f"Successfully wrote to {path}"
            else:
                return f"Unsupported operation: {operation}"
        except Exception as e:
            return f"Error performing file operation: {str(e)}"

class DataProcessingTool(BaseTool):
    """Tool for processing and analyzing data."""
    
    name = "data_processor"
    description = "Process and analyze data in various formats"
    
    def _run(self, data: str, operation: str) -> str:
        """Execute the data processing operation."""
        try:
            # Parse input data
            data_dict = json.loads(data) if isinstance(data, str) else data
            
            if operation == "summarize":
                return self._summarize_data(data_dict)
            elif operation == "analyze":
                return self._analyze_data(data_dict)
            else:
                return f"Unsupported operation: {operation}"
        except Exception as e:
            return f"Error processing data: {str(e)}"
    
    def _summarize_data(self, data: Dict) -> str:
        """Summarize the data structure."""
        summary = {
            "type": str(type(data)),
            "keys": list(data.keys()) if isinstance(data, dict) else None,
            "length": len(data),
        }
        return json.dumps(summary, indent=2)
    
    def _analyze_data(self, data: Dict) -> str:
        """Perform basic analysis on the data."""
        analysis = {
            "structure": {
                "type": str(type(data)),
                "depth": self._get_dict_depth(data),
                "total_keys": self._count_keys(data),
            }
        }
        return json.dumps(analysis, indent=2)
    
    def _get_dict_depth(self, d: Dict) -> int:
        """Get the maximum depth of a nested dictionary."""
        if not isinstance(d, dict) or not d:
            return 0
        return 1 + max(self._get_dict_depth(v) for v in d.values() if isinstance(v, dict))
    
    def _count_keys(self, d: Dict) -> int:
        """Count total number of keys in a nested dictionary."""
        count = len(d)
        for v in d.values():
            if isinstance(v, dict):
                count += self._count_keys(v)
        return count