from typing import Dict, List, Optional, Any
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
from langchain.agents import AgentExecutor, create_react_agent
from langchain_core.tools import Tool, BaseTool
from langchain_core.prompts import PromptTemplate
from .types import AgentDefinition, UserRequest, ToolDefinition
from .tools.registry import ToolRegistry
from .db import AgentDatabase
import json
import os
from datetime import datetime
import logging

class AgentiX:
    """Main class for the AgentiX system."""
    
    def __init__(self):
        # Setup logging first
        self._setup_logging()
        
        # Initialize other components
        self.llm = ChatOpenAI(model="gpt-4o", temperature=0)
        self.tool_registry = ToolRegistry(llm=self.llm)
        self.db = AgentDatabase()
        from .graph_agent import AgentiXGraph
        self.graph = AgentiXGraph()
        self.agents_file = "agents.json"
    
    def _setup_logging(self):
        """Setup logging for the AgentiX system."""
        self.logger = logging.getLogger("agentix")
        self.logger.setLevel(logging.INFO)
        
        # Add handler if none exists
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            
        self.logger.info("AgentiX logging initialized")
    
    def get_all_agents(self) -> List[AgentDefinition]:
        """Get all available agents."""
        return self.db.search_agents("")
    
    def search_agents(self, query: str) -> List[AgentDefinition]:
        """Search for agents by name or description."""
        all_agents = self.get_all_agents()
        if not query:
            return all_agents
            
        return [
            agent for agent in all_agents
            if query.lower() in agent.agent_name.lower() or
            query.lower() in agent.agent_description.lower()
        ]
    
    def generate_tool(
        self,
        name: str,
        description: str,
        requirements: List[str]
    ) -> str:
        """Generate a new tool implementation."""
        tool = self.tool_registry.generate_tool_implementation(
            name=name,
            description=description,
            requirements=requirements
        )
        self.tool_registry.register_tool(tool)
        return tool.code
    
    def get_agent_code(self, idea_input: str) -> str:
        """Generate agent code based on user input."""
        self.logger.info(f"Generating agent code for: {idea_input}")
        
        try:
            # First, understand the requirements
            requirements = self._analyze_requirements(idea_input)
            self.logger.info(f"Analyzed requirements: {requirements}")
            
            # Check existing agents
            existing_agent = self._find_matching_agent(requirements)
            if existing_agent:
                self.logger.info(f"Found matching existing agent: {existing_agent['name']}")
                return self._generate_agent_code(existing_agent)
                
            # Create new agent if no match found
            self.logger.info("No matching agent found, creating new one")
            new_agent = self._create_new_agent(requirements)
            if not new_agent:
                error_msg = "Failed to create new agent - check logs for details"
                self.logger.error(error_msg)
                raise ValueError(error_msg)
                
            # Save the new agent
            self.logger.info("Saving new agent")
            self._save_agent(new_agent)
            
            # Generate and return the code
            self.logger.info("Generating code for new agent")
            return self._generate_agent_code(new_agent)
            
        except Exception as e:
            self.logger.error(f"Error in get_agent_code: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            raise

    def _analyze_requirements(self, idea_input: str) -> Dict[str, Any]:
        """Analyze user input to understand requirements."""
        try:
            prompt = f"""Analyze the following user request and extract key requirements:

Request: {idea_input}

Please identify:
1. Main functionality needed
2. Required tools
3. Input/output formats
4. Special requirements (API access, file handling, etc.)
5. Performance considerations

Return the analysis as a JSON object with these fields:
{{
    "name": "descriptive_name",
    "description": "detailed_description",
    "tools": ["tool1", "tool2"],
    "requirements": ["req1", "req2"],
    "input_format": "description",
    "output_format": "description",
    "special_requirements": ["req1", "req2"]
}}

IMPORTANT: Return ONLY the JSON object, no additional text or explanation."""

            # Get response from LLM
            response = self.llm.invoke(prompt)
            
            # Extract content from AIMessage
            if hasattr(response, 'content'):
                response_text = response.content
            else:
                response_text = str(response)
            
            # Clean the response text
            response_text = response_text.strip()
            if response_text.startswith("```json"):
                response_text = response_text.split("```json")[1]
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            response_text = response_text.strip()
            
            # Parse JSON
            self.logger.debug(f"Parsing JSON response: {response_text}")
            requirements = json.loads(response_text)
            
            # Validate requirements
            required_fields = [
                "name", "description", "tools", "requirements",
                "input_format", "output_format", "special_requirements"
            ]
            for field in required_fields:
                if field not in requirements:
                    raise ValueError(f"Missing required field in requirements: {field}")
                    
            return requirements
            
        except Exception as e:
            self.logger.error(f"Error analyzing requirements: {str(e)}")
            self.logger.error(f"Response was: {response_text if 'response_text' in locals() else 'No response'}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            raise

    def _find_matching_agent(self, requirements: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Find an existing agent that matches requirements."""
        try:
            # Load existing agents
            if not os.path.exists(self.agents_file):
                self.logger.info("No agents file exists yet")
                return None
            
            with open(self.agents_file, 'r') as f:
                data = json.load(f)
                if not isinstance(data, dict) or "agents" not in data:
                    self.logger.error("Invalid agents file format")
                    return None
                agents = data["agents"]
            
            # Score each agent based on requirement match
            best_match = None
            best_score = 0
            
            for agent in agents:
                if not isinstance(agent, dict):
                    continue
                score = self._calculate_match_score(agent, requirements)
                if score > best_score:
                    best_score = score
                    best_match = agent
            
            # Return match if score is above threshold
            if best_score >= 0.8:  # 80% match threshold
                return best_match
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error finding matching agent: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            return None

    def _calculate_match_score(self, agent: Dict[str, Any], requirements: Dict[str, Any]) -> float:
        """Calculate how well an agent matches requirements."""
        try:
            score = 0.0
            total_weight = 0.0
            
            # Check tools match (highest weight)
            weight = 0.4
            total_weight += weight
            required_tools = requirements.get('tools', [])
            agent_tools = agent.get('tools', [])
            if required_tools:
                # Convert tool names/identifiers to strings for comparison
                required_tool_names = set(str(t) for t in required_tools)
                agent_tool_names = set(
                    t['name'] if isinstance(t, dict) else str(t) 
                    for t in agent_tools
                )
                tool_match = len(required_tool_names.intersection(agent_tool_names)) / len(required_tool_names)
            else:
                tool_match = 0.0
            score += weight * tool_match
            
            # Check requirements match
            weight = 0.3
            total_weight += weight
            required_reqs = set(str(r) for r in requirements.get('requirements', []))
            agent_reqs = set(str(r) for r in agent.get('requirements', []))
            if required_reqs:
                req_match = len(required_reqs.intersection(agent_reqs)) / len(required_reqs)
            else:
                req_match = 0.0
            score += weight * req_match
            
            # Check special requirements
            weight = 0.2
            total_weight += weight
            special_reqs = set(str(r) for r in requirements.get('special_requirements', []))
            agent_special = set(str(r) for r in agent.get('special_requirements', []))
            if special_reqs:
                special_match = len(special_reqs.intersection(agent_special)) / len(special_reqs)
            else:
                special_match = 1.0
            score += weight * special_match
            
            # Description similarity (basic text matching)
            weight = 0.1
            total_weight += weight
            req_desc = str(requirements.get('description', '')).lower()
            agent_desc = str(agent.get('description', '')).lower()
            desc_match = float(
                len(set(req_desc.split()) & set(agent_desc.split())) / 
                max(len(set(req_desc.split())), 1)
            )
            score += weight * desc_match
            
            # Normalize score
            if total_weight > 0:
                return score / total_weight
            return 0.0
            
        except Exception as e:
            self.logger.error(f"Error calculating match score: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            return 0.0

    def _create_new_agent(self, requirements: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create a new agent based on requirements."""
        try:
            self.logger.info("Starting new agent creation")
            self.logger.debug(f"Requirements: {requirements}")
            
            # Generate tools first
            tools = []
            required_tools = requirements.get('tools', [])
            self.logger.info(f"Generating {len(required_tools)} tools")
            
            for tool_name in required_tools:
                self.logger.info(f"Generating tool: {tool_name}")
                tool = self.tool_registry.generate_tool_implementation(
                    name=tool_name,
                    description=f"Tool for {tool_name}"
                )
                if not tool:
                    error_msg = f"Failed to generate tool: {tool_name}"
                    self.logger.error(error_msg)
                    raise ValueError(error_msg)
                    
                # Verify tool was registered
                if not self.tool_registry.get_tool(tool.identifier):
                    error_msg = f"Tool {tool_name} was generated but not registered"
                    self.logger.error(error_msg)
                    raise ValueError(error_msg)
                    
                tools.append(tool)
                self.logger.info(f"Successfully generated and registered tool: {tool_name}")
            
            # Verify all tools are ready
            if len(tools) != len(required_tools):
                error_msg = f"Not all tools were created. Expected {len(required_tools)}, got {len(tools)}"
                self.logger.error(error_msg)
                raise ValueError(error_msg)
            
            # Create agent definition
            self.logger.info("Creating agent definition")
            agent = {
                "name": requirements['name'],
                "description": requirements['description'],
                "tools": [t.identifier for t in tools],  # Store identifiers instead of names
                "requirements": requirements['requirements'],
                "special_requirements": requirements['special_requirements'],
                "input_format": requirements['input_format'],
                "output_format": requirements['output_format'],
                "created_at": datetime.now().isoformat(),
                "version": "1.0.0",
                "model_name": "gpt-4o"
            }
            
            # Verify agent definition
            required_fields = [
                "name", "description", "tools", "requirements",
                "special_requirements", "input_format", "output_format"
            ]
            for field in required_fields:
                if not agent.get(field):
                    error_msg = f"Missing required field in agent definition: {field}"
                    self.logger.error(error_msg)
                    raise ValueError(error_msg)
            
            self.logger.info(f"Successfully created agent: {agent['name']}")
            return agent
            
        except Exception as e:
            self.logger.error(f"Error creating new agent: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            return None

    def _save_agent(self, agent: Dict[str, Any]) -> None:
        """Save agent definition to JSON file."""
        try:
            # Load existing agents
            agents_data = {"agents": []}
            if os.path.exists(self.agents_file):
                with open(self.agents_file, 'r') as f:
                    agents_data = json.load(f)
                    if not isinstance(agents_data, dict):
                        agents_data = {"agents": []}
                    if "agents" not in agents_data:
                        agents_data["agents"] = []
                    
            # Add new agent
            agents_data["agents"].append(agent)
            
            # Save updated list
            with open(self.agents_file, 'w') as f:
                json.dump(agents_data, f, indent=2)
                
        except Exception as e:
            self.logger.error(f"Error saving agent: {str(e)}")
            raise

    def _generate_agent_code(self, agent: Dict[str, Any]) -> str:
        """Generate the final agent code."""
        try:
            self.logger.info(f"Generating code for agent: {agent['name']}")
            
            # Get tool implementations
            tools = []
            for tool_name in agent['tools']:
                self.logger.info(f"Getting implementation for tool: {tool_name}")
                tool = self.tool_registry.get_tool(tool_name)
                if not tool:
                    error_msg = f"Tool not found: {tool_name}"
                    self.logger.error(error_msg)
                    raise ValueError(error_msg)
                tools.append(tool)
                
            # Generate code
            code = f"""# Generated Agent: {agent['name']}
# Description: {agent['description']}
# Version: {agent['version']}

from langchain_core.agents import AgentExecutor
from langchain_core.tools import BaseTool
from langchain.agents import create_react_agent
from langchain_core.prompts import PromptTemplate
from langchain.chat_models import ChatOpenAI

# Tool Implementations
{chr(10).join(t.code for t in tools)}

def create_agent():
    \"\"\"Create and return the agent.\"\"\"
    # Initialize tools
    tools = [
        {', '.join(f'{t.name}()' for t in tools)}
    ]
    
    # Initialize LLM
    llm = ChatOpenAI(
        model_name="gpt-4o",  # Always use gpt-4o
        temperature=0
    )
    
    # Create prompt
    prompt = PromptTemplate.from_template(
        \"\"\"You are an AI assistant that helps users with {agent['description']}.
        
        You have access to the following tools:
        {chr(10).join(f'- {t.name}: {t.description}' for t in tools)}
        
        Follow the ReAct framework:
        1. Think about what needs to be done
        2. Choose the appropriate tool
        3. Use the tool
        4. Observe the result
        5. Plan next action or provide final answer
        
        User Input: {{input}}
        
        Think through this step-by-step:
        1) First, analyze the input
        2) Then, decide which tool to use
        3) Finally, provide a clear response
        
        {{agent_scratchpad}}
        \"\"\"
    )
    
    # Create agent
    agent = create_react_agent(llm, tools, prompt)
    
    # Create executor
    return AgentExecutor(
        agent=agent,
        tools=tools,
        verbose=True,
        handle_parsing_errors=True
    )

# Usage example
if __name__ == "__main__":
    agent = create_agent()
    result = agent.invoke({{"input": "Your query here"}})
    print(result)
"""
            
            self.logger.info("Successfully generated agent code")
            return code
            
        except Exception as e:
            self.logger.error(f"Error generating agent code: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            raise

    def analyze_requirements(self, request: UserRequest) -> Dict[str, Any]:
        """Analyze user requirements to determine needed tools and capabilities."""
        prompt = f"""Analyze the following agent requirements and identify needed tools and capabilities:
            
Requirements: {request.description}

Return a JSON object with:
1. required_tools: List of tool definitions needed
2. agent_type: Type of agent needed (e.g., "sequential", "parallel", "conversational")
3. complexity_score: Estimated complexity (1-10)
4. suggested_name: A descriptive name for the agent
5. suggested_prompt: A ReAct prompt template for the agent

Format the response as a valid JSON object."""

        response = self.llm.invoke([HumanMessage(content=prompt)])
        return json.loads(response.content)

    def validate_agent_pipeline(self, agent_def: AgentDefinition) -> bool:
        """Validate that an agent's pipeline is complete and functional."""
        try:
            # Get tool implementations
            tools = []
            for tool_def in agent_def.tools:
                impl = self.tool_registry.get_tool(tool_def.identifier)
                if not impl:
                    return False
                tools.append(impl)
            
            # Create test agent
            test_prompt = "This is a test prompt to validate the agent pipeline."
            graph = self.graph.create_agent_graph(tools, agent_def.agent_prompt)
            
            # Run basic validation
            test_state = {"messages": [HumanMessage(content=test_prompt)], "next_step": "agent"}
            graph.invoke(test_state)
            
            return True
        except Exception as e:
            print(f"Pipeline validation failed: {str(e)}")
            return False

    def create_agent(self, request: UserRequest) -> Optional[AgentDefinition]:
        """Create a new agent based on user requirements."""
        try:
            # Analyze requirements
            analysis = self.analyze_requirements(request)
            
            # Check for existing tools
            needed_tools = []
            for tool_req in analysis["required_tools"]:
                # Search existing tools
                existing_tools = self.tool_registry.search_tools(tool_req["name"])
                if existing_tools:
                    needed_tools.append(ToolDefinition(
                        name=existing_tools[0].name,
                        description=existing_tools[0].description,
                        identifier=existing_tools[0].identifier
                    ))
                else:
                    # Generate new tool
                    new_tool = self.tool_registry.generate_tool_implementation(
                        name=tool_req["name"],
                        description=tool_req["description"],
                        requirements=tool_req.get("requirements", [])
                    )
                    self.tool_registry.register_tool(new_tool)
                    needed_tools.append(ToolDefinition(
                        name=new_tool.name,
                        description=new_tool.description,
                        identifier=new_tool.identifier
                    ))
            
            # Create agent definition
            agent_def = AgentDefinition(
                agent_name=analysis["suggested_name"],
                agent_description=request.description,
                agent_prompt=analysis["suggested_prompt"],
                tools=needed_tools,
                memory_type="buffer",
                model_name="gpt-4o",
                agent_chain_type="ZERO_SHOT_REACT_DESCRIPTION"
            )
            
            # Validate pipeline
            if not self.validate_agent_pipeline(agent_def):
                raise ValueError("Agent pipeline validation failed")
            
            # Store agent
            self.db.store_agent(agent_def)
            return agent_def
            
        except Exception as e:
            print(f"Error creating agent: {str(e)}")
            return None

    def create_agent_executor(self, agent: AgentDefinition):
        """Create an agent executor from an agent definition."""
        try:
            self.logger.info(f"Creating agent executor for {agent.agent_name}")
            
            # Get tool implementations
            tools = []
            tool_names = []
            tool_descriptions = []
            
            for tool_def in agent.tools:
                tool_impl = self.tool_registry.get_tool(tool_def.identifier)
                if not tool_impl:
                    raise ValueError(f"Tool not found: {tool_def.identifier}")
                
                # Create a function that will execute the tool's code
                exec_globals = {
                    'Tool': Tool,
                    'BaseTool': BaseTool,
                    'ChatOpenAI': ChatOpenAI,
                    'PromptTemplate': PromptTemplate,
                    'os': os,
                    'json': json,
                    'requests': __import__('requests'),
                    'logging': logging
                }
                
                try:
                    # Execute the tool code in our prepared environment
                    exec(tool_impl.code, exec_globals)
                    
                    # Find the tool class that inherits from BaseTool
                    tool_class = None
                    for var_name, var_value in exec_globals.items():
                        if isinstance(var_value, type) and issubclass(var_value, BaseTool) and var_value != BaseTool:
                            tool_class = var_value
                            break
                    
                    if tool_class:
                        # Create an instance of the tool class
                        tool_instance = tool_class()
                        tools.append(tool_instance)
                        tool_names.append(tool_instance.name)
                        tool_descriptions.append(f"{tool_instance.name}: {tool_instance.description}")
                    else:
                        raise ValueError(f"No BaseTool class found for {tool_def.identifier}")
                    
                except Exception as e:
                    self.logger.error(f"Error setting up tool {tool_def.identifier}: {str(e)}")
                    raise
            
            # Initialize LLM
            llm = ChatOpenAI(
                model_name=agent.model_name,
                temperature=0
            )
            
            # Create prompt with required variables
            prompt = PromptTemplate.from_template(
                """You are an AI assistant that helps users with {description}.

Available tools:
{tools}

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of [{tool_names}]
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question

Begin!

Question: {input}
{agent_scratchpad}"""
            )
            
            # Create agent
            agent_chain = create_react_agent(
                llm=llm,
                tools=tools,
                prompt=prompt.partial(
                    description=agent.agent_description,
                    tools="\n".join(tool_descriptions),
                    tool_names=", ".join(tool_names)
                )
            )
            
            # Create executor
            return AgentExecutor(
                agent=agent_chain,
                tools=tools,
                verbose=True,
                handle_parsing_errors=True
            )
            
        except Exception as e:
            self.logger.error(f"Error creating agent executor: {str(e)}")
            import traceback
            self.logger.error(f"Traceback: {traceback.format_exc()}")
            raise