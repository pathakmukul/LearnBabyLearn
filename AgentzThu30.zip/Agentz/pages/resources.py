import streamlit as st
from agentix.core import AgentiX
from typing import List
from agentix.types import AgentDefinition

def delete_agent(agentix: AgentiX, agent_name: str) -> bool:
    """Delete an agent and its unique tools."""
    try:
        # Get the agent definition first
        agent = None
        for a in agentix.search_agents(""):
            if a.agent_name == agent_name:
                agent = a
                break
                
        if not agent:
            return False
            
        # Get all tool identifiers used by this agent
        agent_tool_ids = {tool.identifier for tool in agent.tools}
        
        # Find which tools are unique to this agent
        all_agents = agentix.search_agents("")
        other_agents_tool_ids = set()
        for other_agent in all_agents:
            if other_agent.agent_name != agent_name:
                other_agents_tool_ids.update(tool.identifier for tool in other_agent.tools)
        
        # Tools unique to this agent
        unique_tool_ids = agent_tool_ids - other_agents_tool_ids
        
        # Delete unique tools from registry
        for tool_id in unique_tool_ids:
            agentix.tool_registry.delete_tool(tool_id)
            
        # Delete agent from database
        agentix.db.delete_agent(agent_name)
        return True
    except Exception as e:
        st.error(f"Error deleting agent: {str(e)}")
        return False

def show_agents_tab(agentix: AgentiX):
    """Show the agents tab with search and filter functionality."""
    st.header("Available Agents")
    
    # Add search/filter for agents
    agent_search = st.text_input(
        "Search agents by name or description:",
        placeholder="E.g., web scraping, research, etc."
    )
    
    # Get filtered agents using the search method
    filtered_agents = agentix.search_agents(agent_search)
    
    # Add sorting options
    sort_col1, sort_col2 = st.columns([2, 1])
    with sort_col1:
        sort_by = st.selectbox(
            "Sort by:",
            ["Name", "Number of Tools"],
            key="agent_sort"
        )
    with sort_col2:
        sort_order = st.radio(
            "Order:",
            ["Ascending", "Descending"],
            horizontal=True,
            key="agent_sort_order"
        )
    
    # Sort agents
    if sort_by == "Name":
        filtered_agents.sort(
            key=lambda x: x.agent_name,
            reverse=(sort_order == "Descending")
        )
    else:  # Number of Tools
        filtered_agents.sort(
            key=lambda x: len(x.tools),
            reverse=(sort_order == "Descending")
        )
    
    # Show total count
    st.markdown(f"**Found {len(filtered_agents)} agents**")
    
    # Display agents in a grid
    if not filtered_agents:
        st.info("No agents found matching your search criteria.")
    else:
        cols = st.columns(2)
        for i, agent in enumerate(filtered_agents):
            with cols[i % 2]:
                with st.expander(f"🤖 {agent.agent_name}", expanded=False):
                    st.markdown(f"**Description:** {agent.agent_description}")
                    st.markdown(f"**Number of Tools:** {len(agent.tools)}")
                    st.markdown("**Tools:**")
                    for tool in agent.tools:
                        st.markdown(f"- {tool.name}: {tool.description}")
                    
                    # Add buttons in columns
                    btn_col1, btn_col2 = st.columns(2)
                    
                    # View details button
                    with btn_col1:
                        if st.button("View Full Details", key=f"view_{agent.agent_name}"):
                            st.markdown("**System Prompt:**")
                            st.code(agent.agent_prompt, language="text")
                            
                            # Show usage example instead of generating code
                            st.markdown("**Usage Example:**")
                            example_code = f'''
from agentix.core import AgentiX

# Initialize AgentiX
agentix = AgentiX()

# Create agent request
request = UserRequest(
    description="I want to use the {agent.agent_name} agent",
    requirements=[]
)

# Get the agent
agent = agentix.find_or_create_agent(request)

# Use the agent
response = agent.run("Your query here")
print(response)
'''
                            st.code(example_code, language="python")
                            
                            # Add download button for example
                            st.download_button(
                                "📥 Download Example",
                                example_code,
                                file_name=f"{agent.agent_name}_example.py",
                                mime="text/plain"
                            )
                    
                    # Delete button
                    with btn_col2:
                        if st.button("🗑️ Delete", key=f"delete_{agent.agent_name}", type="secondary"):
                            if delete_agent(agentix, agent.agent_name):
                                st.success(f"Agent '{agent.agent_name}' deleted successfully!")
                                st.rerun()  # Refresh the page
                            else:
                                st.error("Failed to delete agent.")

def show_tools_tab(agentix: AgentiX):
    """Show the tools tab with search and filter functionality."""
    st.header("Available Tools")
    
    # Add search/filter for tools
    tool_search = st.text_input(
        "Search tools by name or description:",
        placeholder="E.g., web search, API, etc."
    )
    
    # Get all tools
    all_tools = list(agentix.tool_registry.tools.values())
    
    # Filter tools based on search
    if tool_search:
        filtered_tools = [
            tool for tool in all_tools
            if tool_search.lower() in tool.name.lower() or
            tool_search.lower() in tool.description.lower()
        ]
    else:
        filtered_tools = all_tools
    
    # Show total count
    st.markdown(f"**Found {len(filtered_tools)} tools**")
    
    # Display tools in a grid
    if not filtered_tools:
        st.info("No tools found matching your search criteria.")
    else:
        cols = st.columns(2)
        for i, tool in enumerate(filtered_tools):
            with cols[i % 2]:
                with st.expander(f"🔧 {tool.name}", expanded=False):
                    st.markdown(f"**Description:** {tool.description}")
                    st.markdown(f"**Version:** {tool.version}")
                    st.markdown("**Dependencies:**")
                    for dep in tool.dependencies:
                        st.markdown(f"- {dep}")
                    
                    # Show implementation
                    st.markdown("**Implementation:**")
                    st.code(tool.code, language="python")
                    
                    # Add download button
                    st.download_button(
                        "📥 Download Code",
                        tool.code,
                        file_name=f"{tool.identifier}.py",
                        mime="text/plain"
                    )

def show_resources_page():
    """Show the available agents and tools page."""
    st.title("Available Agents & Tools")
    
    # Initialize AgentiX
    agentix = AgentiX()
    
    # Create tabs for Agents and Tools
    agents_tab, tools_tab = st.tabs(["📦 Agents", "🔧 Tools"])
    
    # Show respective tabs
    with agents_tab:
        show_agents_tab(agentix)
    
    with tools_tab:
        show_tools_tab(agentix) 