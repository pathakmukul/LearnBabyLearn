import streamlit as st
from agentix.core import AgentiX
from agentix.types import AgentDefinition, UserRequest, ToolDefinition
from typing import List, Optional
import json
from langchain_openai import ChatOpenAI
from langgraph.graph import Graph, StateGraph, END
from langchain_core.tools import BaseTool, Tool
from langchain_core.messages import BaseMessage, FunctionMessage, HumanMessage
from langchain_core.prompts import PromptTemplate, ChatPromptTemplate, MessagesPlaceholder
from langchain.chains import LLMChain
from langchain.agents import AgentExecutor, create_openai_functions_agent
from langchain.agents.format_scratchpad import format_to_openai_function_messages
from langchain.agents.output_parsers import OpenAIFunctionsAgentOutputParser
from typing import TypedDict, Annotated, Sequence
import operator
import os
import time
import pandas as pd

class AgentState(TypedDict):
    """State of the agent system."""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    next_step: str

def init_chat_history():
    """Initialize chat history in session state if not present."""
    if "messages" not in st.session_state:
        st.session_state.messages = []

def display_chat_message(role: str, content: str):
    """Display a chat message with appropriate styling."""
    if role == "user":
        st.chat_message("user").write(content)
    elif role == "assistant":
        # Try to parse content as JSON to extract chain of thought
        try:
            data = json.loads(content)
            
            # Skip if this message has already been displayed
            if data.get("_displayed"):
                return
            
            # Display in a chat message container
            with st.chat_message("assistant"):
                # Display the final answer
                output = data.get("output", "No response")
                if isinstance(output, str):
                    st.markdown("### Response")
                    st.write(output)
                
                # Display chain of thought in an expander
                if "chain_of_thought" in data:
                    with st.expander("🤔 Agent's Thoughts", expanded=True):
                        for step in data["chain_of_thought"]:
                            step_type = step.get("type", "")
                            
                            if step_type == "thought":
                                st.info(f"🤔 Thought: {step['content']}")
                            elif step_type == "action":
                                st.warning(f"🛠️ Using {step['tool']}\n\nInput: {step['input']}")
                            elif step_type == "observation":
                                st.success(f"👁️ Result: {step['content']}")
                            elif step_type == "final_answer":
                                st.info(f"✨ Final Answer: {step['content']}")
                            
                            # Add some spacing between steps
                            st.markdown("---")
                            
        except (json.JSONDecodeError, AttributeError) as e:
            # If not JSON or if there's an attribute error, display as is
            st.chat_message("assistant").write(content)
    elif role == "system":
        st.chat_message("system").write(content)
    elif role == "error":
        st.error(content)

def load_agent(agentix: AgentiX, agent_name: str) -> Optional[AgentDefinition]:
    """Load an agent by name."""
    agents = agentix.search_agents("")  # Get all agents
    for agent in agents:
        if agent.agent_name == agent_name:
            return agent
    return None

def get_tool_implementations(agentix: AgentiX, tool_defs: List[ToolDefinition]) -> List[Tool]:
    """Get actual tool implementations from the registry."""
    tools = []
    
    for tool_def in tool_defs:
        # Get implementation from registry
        impl = agentix.tool_registry.get_tool(tool_def.identifier)
        if impl:
            try:
                # Create a function that will execute the tool's code
                exec_globals = {
                    'Tool': Tool,
                    'BaseTool': BaseTool,
                    'ChatOpenAI': ChatOpenAI,
                    'PromptTemplate': PromptTemplate,
                    'LLMChain': LLMChain,
                    'llm': ChatOpenAI(model="gpt-4"),
                    'os': os,
                    'json': json,
                    'requests': __import__('requests'),
                    'dotenv': __import__('dotenv')
                }
                
                # Execute the tool code in our prepared environment
                exec(impl.code, exec_globals)
                
                # Look for a get_tool function or tool instance
                tool_instance = None
                if 'get_tool' in exec_globals:
                    tool_instance = exec_globals['get_tool']()
                else:
                    # Look for a Tool instance
                    for var_name, var_value in exec_globals.items():
                        if isinstance(var_value, (Tool, BaseTool)):
                            tool_instance = var_value
                            break
                
                if tool_instance is None:
                    st.error(f"No tool instance or get_tool function found for {tool_def.identifier}")
                    continue
                
                tools.append(tool_instance)
                
            except Exception as e:
                st.error(f"Error loading tool {tool_def.identifier}: {str(e)}")
                import traceback
                st.error(f"Traceback: {traceback.format_exc()}")
                continue
        else:
            st.error(f"Tool {tool_def.identifier} not found in registry")
    
    if not tools:
        st.error("No tool implementations found for this agent.")
    
    return tools

def message_to_dict(message: BaseMessage) -> dict:
    """Convert a LangChain message to a dictionary."""
    return {
        "type": message.__class__.__name__,
        "content": message.content,
        "additional_kwargs": message.additional_kwargs
    }

def create_agent_graph(tools: List[Tool], system_prompt: str) -> Graph:
    """Create the LangGraph workflow for agent execution."""
    workflow = StateGraph(AgentState)
    
    # Initialize LLM with lower temperature and gpt-3.5-turbo
    try:
        llm = ChatOpenAI(
            model="gpt-4o",
            temperature=0,
            max_tokens=1000
        )
    except Exception as e:
        raise ValueError(f"Failed to initialize LLM: {str(e)}")

    # Create the agent with tools
    prompt = ChatPromptTemplate.from_messages([
        ("system", f"{system_prompt}\n\nWhen using tools, always follow this format:\nThought: Think about what to do\nAction: tool_name\nAction Input: input to the tool\nObservation: tool output\nThought: Think about what the output means\n... (repeat as needed)\nFinal Answer: The final response when task is complete"),
        MessagesPlaceholder(variable_name="chat_history"),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad")
    ])
    
    # Create the agent
    agent = create_openai_functions_agent(llm, tools, prompt)
    
    # Create the agent executor with proper configuration
    agent_executor = AgentExecutor(
        agent=agent,
        tools=tools,
        handle_parsing_errors=True,
        max_iterations=5,
        early_stopping_method="force",
        verbose=True,
        return_intermediate_steps=True
    )

    def should_continue(state: AgentState) -> str:
        """Determine if we should continue or stop."""
        messages = state["messages"]
        if not messages:
            return "continue"
            
        last_message = messages[-1]
        
        # If it's a function message containing a final answer, stop
        if isinstance(last_message, FunctionMessage):
            try:
                content = json.loads(last_message.content)
                if "output" in content:
                    output = content["output"]
                    if "Final Answer:" in output:
                        return "end"
                    if not content.get("intermediate_steps"):
                        return "end"
            except:
                pass
        
        # If we've hit our iteration limit (5 iterations), stop
        if len([m for m in messages if isinstance(m, FunctionMessage)]) >= 5:
            return "end"
            
        return "continue"

    def agent_node(state: AgentState) -> AgentState:
        """Process the agent's response."""
        try:
            # Get the last message
            last_message = state["messages"][-1]
            
            # Create a single message container for the entire response
            message_container = st.chat_message("assistant")
            with message_container:
                # Create containers for real-time updates
                thoughts_container = st.container()
                with thoughts_container:
                    with st.expander("🤔 Agent's Thoughts", expanded=True):
                        thoughts_area = st.container()
                response_container = st.empty()
            
            try:
                # Run the agent executor
                result = agent_executor.invoke({
                    "input": last_message.content,
                    "chat_history": state["messages"][:-1]
                })
                
                # Convert intermediate steps to serializable format
                serializable_steps = []
                chain_of_thought = []
                
                # Process intermediate steps and build chain of thought
                for step in result.get("intermediate_steps", []):
                    if isinstance(step, tuple) and len(step) == 2:
                        action, observation = step
                        # Add to serializable steps
                        serializable_steps.append({
                            "action": {
                                "tool": action.tool,
                                "tool_input": action.tool_input,
                                "log": action.log
                            },
                            "observation": observation
                        })
                        
                        # Add to chain of thought
                        if action.log:
                            chain_of_thought.append({
                                "type": "thought",
                                "content": action.log
                            })
                        chain_of_thought.append({
                            "type": "action",
                            "tool": action.tool,
                            "input": action.tool_input
                        })
                        chain_of_thought.append({
                            "type": "observation",
                            "content": observation
                        })
                        
                        # Update thoughts display in real-time
                        with thoughts_area:
                            if action.log:
                                st.info(f"🤔 Thought: {action.log}")
                            st.warning(f"🛠️ Using {action.tool}\n\nInput: {action.tool_input}")
                            st.success(f"👁️ Result: {observation}")
                            st.markdown("---")
                
                # Extract final answer if present
                output = result["output"]
                if "Final Answer:" in output:
                    # Extract just the final answer part
                    final_answer = output.split("Final Answer:")[-1].strip()
                    chain_of_thought.append({
                        "type": "final_answer",
                        "content": final_answer
                    })
                    # Add final answer to thoughts
                    with thoughts_area:
                        st.info(f"✨ Final Answer: {final_answer}")
                        st.markdown("---")
                else:
                    final_answer = output
                
                # Update response with final answer
                with response_container:
                    st.markdown("### Response")
                    st.write(final_answer)
                
                # Convert result to a serializable format
                serializable_response = {
                    "output": final_answer,
                    "intermediate_steps": serializable_steps,
                    "chain_of_thought": chain_of_thought,
                    "_displayed": True  # Mark that this response has already been displayed
                }
                
            finally:
                # No need to clean up containers as they're within the chat message
                pass
            
            # Add response to messages
            state["messages"].append(FunctionMessage(
                name="agent",
                content=json.dumps(serializable_response)
            ))
            
            return state
            
        except Exception as e:
            st.error(f"Agent error: {str(e)}")
            import traceback
            st.error(f"Traceback: {traceback.format_exc()}")
            state["messages"].append(FunctionMessage(
                name="error",
                content=str(e)
            ))
            return state
    
    # Add nodes
    workflow.add_node("agent", agent_node)
    
    # Add edges
    workflow.add_conditional_edges(
        "agent",
        should_continue,
        {
            "continue": "agent",
            "end": END
        }
    )
    
    # Set entry point
    workflow.set_entry_point("agent")
    
    return workflow.compile()

def show_playground_page():
    """Show the agent playground page with chat interface."""
    st.title("🎮 Agent Playground")
    
    # Initialize AgentiX
    agentix = AgentiX()
    
    # Get all available agents
    agents = agentix.search_agents("")
    agent_names = [agent.agent_name for agent in agents]
    
    # Create columns for layout
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Agent selection
        selected_agent_name = st.selectbox(
            "Select an Agent:",
            [""] + agent_names,
            index=0,
            placeholder="Choose an agent to interact with"
        )
        
        if not selected_agent_name:
            st.info("Please select an agent to begin.")
            return
        
        # Load selected agent definition
        agent_def = load_agent(agentix, selected_agent_name)
        if not agent_def:
            st.error(f"Could not load agent: {selected_agent_name}")
            return
        
        # Create or get agent instance if agent changed
        if "current_agent_name" not in st.session_state or st.session_state.current_agent_name != selected_agent_name:
            try:
                # Get tool implementations
                tools = get_tool_implementations(agentix, agent_def.tools)
                if not tools:
                    st.error("No tool implementations found for this agent.")
                    return
                
                # Create LangGraph agent
                st.session_state.agent_graph = create_agent_graph(
                    tools=tools,
                    system_prompt=agent_def.agent_prompt
                )
                st.session_state.current_agent_name = selected_agent_name
                
                # Initialize agent state with empty message list
                st.session_state.agent_state = AgentState(
                    messages=[],
                    next_step="agent"
                )
                
                # Initialize metrics
                st.session_state.metrics = {
                    "total_calls": 0,
                    "successful_calls": 0,
                    "failed_calls": 0,
                    "average_response_time": 0,
                    "tool_usage": {}
                }
            
            except Exception as e:
                st.error(f"Error initializing agent: {str(e)}")
                return
        
        # Initialize chat history
        init_chat_history()
        
        # Display chat messages
        for message in st.session_state.messages:
            display_chat_message(message["role"], message["content"])
        
        # Chat input
        if prompt := st.chat_input("Type your message here..."):
            # Add user message to chat history
            st.session_state.messages.append({"role": "user", "content": prompt})
            display_chat_message("user", prompt)
            
            # Update agent state with new message
            st.session_state.agent_state["messages"].append(HumanMessage(content=prompt))
            
            with st.spinner("Agent is thinking..."):
                try:
                    # Start timing
                    start_time = time.time()
                
                    # Run the agent graph
                    final_state = st.session_state.agent_graph.invoke(st.session_state.agent_state)
                
                # Update metrics
                    st.session_state.metrics["total_calls"] += 1
                    st.session_state.metrics["successful_calls"] += 1
                    response_time = time.time() - start_time
                    st.session_state.metrics["average_response_time"] = (
                            (st.session_state.metrics["average_response_time"] * 
                             (st.session_state.metrics["successful_calls"] - 1) + 
                             response_time) / 
                            st.session_state.metrics["successful_calls"]
                        )
                    
                    # Update agent state
                    st.session_state.agent_state = final_state
                    
                    # Display agent response
                    if final_state["messages"]:
                        last_message = final_state["messages"][-1]
                        if isinstance(last_message, FunctionMessage):
                            try:
                                response_data = json.loads(last_message.content)
                                
                                # Update tool usage metrics
                                for step in response_data.get("intermediate_steps", []):
                                    if isinstance(step, tuple) and len(step) == 2:
                                        tool_name = step[0].tool
                                    elif isinstance(step, dict):
                                        tool_name = step.get("action", {}).get("tool")
                                    else:
                                        continue
                                        
                                    if tool_name:
                                        st.session_state.metrics["tool_usage"][tool_name] = (
                                            st.session_state.metrics["tool_usage"].get(tool_name, 0) + 1
                                        )
                                
                                # Add to chat history
                                st.session_state.messages.append({
                                    "role": "assistant",
                                    "content": last_message.content  # Store the full JSON for proper display
                                })
                                
                                # Display the message
                                display_chat_message("assistant", last_message.content)
                                
                            except json.JSONDecodeError:
                                st.session_state.messages.append({
                                    "role": "assistant",
                                    "content": last_message.content
                                })
                                display_chat_message("assistant", last_message.content)
                        else:
                            st.session_state.messages.append({
                                "role": "assistant",
                                "content": last_message.content
                            })
                            display_chat_message("assistant", last_message.content)
                except Exception as e:
                    st.session_state.metrics["failed_calls"] += 1
                    st.error(f"Error running agent: {str(e)}")
                    import traceback
                    with st.expander("View Error Details", expanded=True):
                        st.code(traceback.format_exc(), language="python")
    
    # Sidebar with metrics and monitoring
    with col2:
        st.markdown("### Agent Metrics")
        
        # Display metrics
        metrics = st.session_state.get("metrics", {
            "total_calls": 0,
            "successful_calls": 0,
            "failed_calls": 0,
            "average_response_time": 0,
            "tool_usage": {}
        })
        
        st.metric("Total Calls", metrics["total_calls"])
        st.metric("Success Rate", 
                 f"{(metrics['successful_calls']/metrics['total_calls']*100):.1f}%" 
                 if metrics['total_calls'] > 0 else "N/A")
        st.metric("Avg Response Time", 
                 f"{metrics['average_response_time']:.2f}s" 
                 if metrics['average_response_time'] > 0 else "N/A")
        
        # Tool usage chart
        if metrics["tool_usage"]:
            st.markdown("### Tool Usage")
            tool_usage_data = pd.DataFrame(
                {"Tool": list(metrics["tool_usage"].keys()),
                 "Calls": list(metrics["tool_usage"].values())}
            )
            st.bar_chart(tool_usage_data.set_index("Tool"))
        
        # Display agent details
        st.markdown("### Agent Details")
        st.markdown(f"**Description:** {agent_def.agent_description}")
        st.markdown("**Available Tools:**")
        for tool in agent_def.tools:
            st.markdown(f"- {tool.name}: {tool.description}")
        
        # Add clear chat button
        if st.button("Clear Chat History"):
            st.session_state.messages = []
            st.session_state.agent_state["messages"] = []
            st.session_state.metrics = {
                "total_calls": 0,
                "successful_calls": 0,
                "failed_calls": 0,
                "average_response_time": 0,
                "tool_usage": {}
            }
            st.rerun()