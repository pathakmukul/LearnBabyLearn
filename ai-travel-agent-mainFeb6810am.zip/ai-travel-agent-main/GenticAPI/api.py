import os
import sys
from dotenv import load_dotenv
load_dotenv()
# Add the project root directory to Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import Dict, Any, List, TypedDict, Annotated
import operator
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from langchain_core.messages import HumanMessage, SystemMessage, AnyMessage, ToolMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from agents.registry_manager import RegistryManager
import uuid

# Constants
OPENAI_MODEL = "gpt-4o"

class DynamicAgentState(TypedDict):
    """State for the dynamic agent workflow."""
    messages: Annotated[list[AnyMessage], operator.add]

class DynamicAgent:
    def __init__(self, agent_config: dict, tools_config: dict):
        self.agent_config = agent_config
        self.tools = {}
        self.setup_tools(tools_config)
        
        # Initialize LLM with tools
        self._tools_llm = ChatOpenAI(model=agent_config.get('model_name', OPENAI_MODEL)).bind_tools(list(self.tools.values()))
        
        # Initialize state graph
        builder = StateGraph(DynamicAgentState)
        
        # Add nodes
        builder.add_node("call_tools_llm", self.call_tools_llm)
        builder.add_node("invoke_tools", self.invoke_tools)
        
        # Set entry point
        builder.set_entry_point("call_tools_llm")
        
        # Add edges
        builder.add_conditional_edges(
            "call_tools_llm",
            self.should_continue,
            {
                "more_tools": "invoke_tools",
                "end": END
            }
        )
        builder.add_edge("invoke_tools", "call_tools_llm")
            
        # Compile graph
        memory = MemorySaver()
        self.graph = builder.compile(checkpointer=memory)

    def setup_tools(self, tools_config: dict):
        """Set up tools from the configuration."""
        try:
            for tool_name in self.agent_config.get('tools', []):
                if isinstance(tool_name, dict):
                    tool_name = tool_name.get('name')
                if tool_name in tools_config:
                    tool_code = tools_config[tool_name].get('code', '')
                    # Create a temporary namespace for the tool
                    tool_namespace = {}
                    try:
                        # Execute the tool code in the namespace
                        exec(tool_code, tool_namespace)
                        # The tool function should be the last item in the namespace
                        tool_function = None
                        for item in tool_namespace.values():
                            if callable(item) and hasattr(item, 'name'):
                                tool_function = item
                                break
                        if tool_function:
                            self.tools[tool_name] = tool_function
                    except Exception as e:
                        print(f"Error setting up tool {tool_name}: {str(e)}")
        except Exception as e:
            print(f"Error in setup_tools: {str(e)}")

    @staticmethod
    def should_continue(state: DynamicAgentState) -> str:
        """Determine if we should continue processing or end."""
        last_message = state['messages'][-1]
        if hasattr(last_message, 'tool_calls') and last_message.tool_calls:
            return "more_tools"
        return "end"

    def call_tools_llm(self, state: DynamicAgentState) -> Dict[str, Any]:
        """Process messages and determine next actions."""
        messages = state['messages']
        
        # Add system prompt if not present
        if not messages or not any(isinstance(m, SystemMessage) for m in messages):
            messages = [SystemMessage(content=self.agent_config.get('agent_prompt', ''))] + messages
        
        try:
            response = self._tools_llm.invoke(messages)
            return {'messages': [response]}
        except Exception as e:
            print(f"Error in LLM call: {str(e)}")
            return {'messages': [HumanMessage(content=f"Error: {str(e)}")]}

    def invoke_tools(self, state: DynamicAgentState) -> Dict[str, Any]:
        """Execute tool calls and process results."""
        tool_calls = state['messages'][-1].tool_calls
        results = []
        
        for t in tool_calls:
            print(f"Calling tool: {t['name']}")
            
            if t['name'] not in self.tools:
                error_msg = f"Invalid tool name: {t['name']}"
                print(error_msg)
                results.append(ToolMessage(tool_call_id=t['id'], name=t['name'], content=error_msg))
                continue
                
            try:
                # Execute tool
                result = self.tools[t['name']].invoke(t['args'])
                results.append(ToolMessage(tool_call_id=t['id'], name=t['name'], content=str(result)))
            except Exception as e:
                error_msg = f"Error in {t['name']}: {str(e)}"
                print(error_msg)
                results.append(ToolMessage(tool_call_id=t['id'], name=t['name'], content=error_msg))
        
        return {'messages': results}

# FastAPI app setup
app = FastAPI(
    title="Gentic API",
    description="API for using Gentic agents",
    version="1.0.0"
)

# Initialize registry manager
registry = RegistryManager()

class AgentRunRequest(BaseModel):
    """Request model for running an agent"""
    message: str

class AgentResponse(BaseModel):
    """Response model for agent execution"""
    response: str

@app.get("/agents")
async def list_agents():
    """List all available agents."""
    try:
        agents = registry.list_agents()
        return {
            "agents": [
                    {
                    "name": name,
                    "description": agent.get('agent_description', ''),
                    "tools": agent.get('tools', [])
                }
                for name, agent in agents.items()
            ]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/agents/{agent_name}/run")
async def run_agent(agent_name: str, request: AgentRunRequest):
    """Run a specific agent with a message."""
    try:
        # Get agent configuration
        agents = registry.list_agents()
        if agent_name not in agents:
            raise HTTPException(status_code=404, detail=f"Agent {agent_name} not found")
            
        agent_config = agents[agent_name]
        tools_config = registry.list_tools()
        
        # Create dynamic agent instance
        agent = DynamicAgent(agent_config, tools_config)
    
        # Process message
        messages = [HumanMessage(content=request.message)]
        config = {
            'configurable': {
                'thread_id': str(uuid.uuid4()),
                'checkpoint_ns': 'api',
                'checkpoint_id': str(uuid.uuid4())
            }
        }
        
        # Run agent
        result = agent.graph.invoke({'messages': messages}, config=config)
        
        # Extract response
        if result and result.get('messages'):
            response = result['messages'][-1].content
        else:
            response = "No response generated"
            
        return AgentResponse(response=response)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001) 