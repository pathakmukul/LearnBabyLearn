import os
import json
import streamlit as st
from agents.gentic_agent import GenticAgent, GenticState
from agents.registry_manager import RegistryManager
from langchain_core.messages import HumanMessage, AIMessage
import uuid

def initialize_agent():
    if 'agent' not in st.session_state:
        st.session_state.agent = GenticAgent()
    if 'registry' not in st.session_state:
        st.session_state.registry = RegistryManager()
    if 'state' not in st.session_state:
        st.session_state.state = {
            "messages": [],
            "current_step": "analyze_requirements",
            "requirements": {},
            "generated_code": ""
        }

def render_custom_css():
    st.markdown(
        '''
        <style>
        .main-title {
            font-size: 2.5em;
            color: #333;
            text-align: center;
            margin-bottom: 0.5em;
            font-weight: bold;
        }
        .sub-title {
            font-size: 1.2em;
            color: #333;
            text-align: left;
            margin-bottom: 0.5em;
        }
        .center-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }
        .query-box {
            width: 80%;
            max-width: 600px;
            margin-top: 0.5em;
            margin-bottom: 1em;
        }
        .query-container {
            width: 80%;
            max-width: 600px;
            margin: 0 auto;
        }
        </style>
        ''', unsafe_allow_html=True)

def render_ui():
    st.markdown('<div class="center-container">', unsafe_allow_html=True)
    st.markdown('<div class="main-title">🧬 Gentic - AI Agent Generator 🤖</div>', unsafe_allow_html=True)
    st.markdown('<div class="query-container">', unsafe_allow_html=True)
    st.markdown('<div class="sub-title">Create Custom AI Agents</div>', unsafe_allow_html=True)
    
    # Main Generation Form
    st.subheader('Agent Generation')
    NAME = st.text_input('Agent Name')
    DESCRIPTION = st.text_area('Agent Description', 
                             help='Describe the functionality and requirements in detail')
    
    MODEL_NAME = st.selectbox('Model', ['gpt-4o', 'gpt-3.5-turbo'])
    MEMORY_TYPE = st.selectbox('Memory Type', ['buffer', 'conversation', 'summary'])
    AGENT_TYPE = st.selectbox('Agent Type', ['ZERO_SHOT_REACT_DESCRIPTION', 'STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION'])
    
    if st.button('Generate'):
        if NAME and DESCRIPTION:
            try:
                with st.spinner('Generating agent...'):
                    # FORCE usage of the user-provided agent name.
                    INITIAL_MESSAGE = (
                        f"Agent requirements:\n"
                        f"Name: {NAME}\n"
                        f"Description: {DESCRIPTION}\n\n"
                        f"IMPORTANT: Please use the user-provided name '{NAME}' as the agent name without modifications."
                    )
                    
                    initial_state = GenticState(
                        messages=[HumanMessage(content=INITIAL_MESSAGE)]
                    )
                    st.write('Starting agent generation process...')
                    progress_container = st.empty()
                    analysis_container = st.empty()
                    with st.expander('Generation Progress', expanded=True):
                        progress_container.write('🔄 Analyzing requirements...')
                        THREAD_ID = str(uuid.uuid4())
                        CONFIG = {"configurable": {"thread_id": THREAD_ID}}
                        result = st.session_state.agent.graph.invoke(initial_state, config=CONFIG)
                        
                        # Display analysis results
                        if result and 'messages' in result:
                            analysis_container.markdown('**Analysis Results:**')
                            for msg in result['messages']:
                                if isinstance(msg, AIMessage):
                                    analysis_container.markdown(f'```\n{msg.content}\n```')
                            
                            progress_container.write('✅ Agent generation completed successfully!')
                            
                    st.write('🎉 Agent generation completed!')
                    
            except Exception as e:
                st.error(f'Error during generation: {str(e)}')
                return
            
            # Display the registered agent
            st.markdown('---')
            st.subheader(f'📚 Generated Agent: {NAME}')
            agent_data = st.session_state.registry.get_agent(NAME)
            if agent_data:
                st.write(f'**Description:** {agent_data.get("agent_description", "No description available")}')
                st.write(f'**Model:** {agent_data.get("model_name", "Not specified")}')
                st.write(f'**Memory:** {agent_data.get("memory_type", "Not specified")}')
                if agent_data.get('tools'):
                    st.markdown('### Required Tools')
                    st.code(json.dumps(agent_data['tools'], indent=2), language='json')
    

def main():
    render_custom_css()
    initialize_agent()
    render_ui()

if __name__ == '__main__':
    main()