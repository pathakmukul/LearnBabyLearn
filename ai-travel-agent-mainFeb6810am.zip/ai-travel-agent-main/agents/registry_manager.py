import json
import os
from typing import Dict, Any

class RegistryManager:
    def __init__(self):
        self.registry_dir = os.path.join(os.path.dirname(__file__), 'registry')
        self.agents_file = os.path.join(self.registry_dir, 'agents.json')
        self.tools_file = os.path.join(self.registry_dir, 'tools.json')
        
        # Ensure registry directory exists
        os.makedirs(self.registry_dir, exist_ok=True)
        
        # Initialize files if they don't exist
        for file_path in [self.agents_file, self.tools_file]:
            if not os.path.exists(file_path):
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump({}, f)
    
    def _load_json(self, file_path: str) -> Dict[str, Any]:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            return {}
    
    def _save_json(self, file_path: str, data: Dict[str, Any]) -> None:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    
    def save_agent(self, agent_id: str, agent_data: Dict[str, Any]) -> None:
        """Save agent configuration to registry"""
        agents = self._load_json(self.agents_file)
        agents[agent_id] = agent_data
        self._save_json(self.agents_file, agents)
    
    def get_agent(self, agent_id: str) -> Dict[str, Any]:
        """Retrieve agent configuration from registry"""
        agents = self._load_json(self.agents_file)
        agent_data = agents.get(agent_id, {})
        # Ensure description field exists
        if 'description' not in agent_data:
            agent_data['description'] = 'No description available'
        return agent_data
    
    def save_tool(self, tool_id: str, tool_data: Dict[str, Any]) -> None:
        """Save tool configuration to registry"""
        tools = self._load_json(self.tools_file)
        tools[tool_id] = tool_data
        self._save_json(self.tools_file, tools)
    
    def get_tool(self, tool_id: str) -> Dict[str, Any]:
        """Retrieve tool configuration from registry"""
        tools = self._load_json(self.tools_file)
        return tools.get(tool_id, {})
    
    def list_agents(self) -> Dict[str, Any]:
        """List all registered agents"""
        agents = self._load_json(self.agents_file)
        # Ensure all agents have a description field
        for agent_data in agents.values():
            if 'description' not in agent_data:
                agent_data['description'] = 'No description available'
        return agents
    
    def list_tools(self) -> Dict[str, Any]:
        """List all registered tools"""
        return self._load_json(self.tools_file)