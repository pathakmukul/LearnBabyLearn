import os
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
import re
class CodeGenerationInput(BaseModel):
    """Input schema for code generation."""
    agent_name: str = Field(description="Name of the agent")
    tool_name: Optional[str] = Field(None, description="Name of the tool if generating a tool")
    description: str = Field(description="Description of functionality")
    model_name: str = Field(default="gpt-4o", description="Model name for agents")
    memory_type: str = Field(default="buffer", description="Memory type for agents")
    agent_type: Optional[str] = Field(None, description="Agent type specification")

class CodeGenerationOutput(BaseModel):
    """Output schema for code generation."""
    code: str = Field(description="Generated implementation code")
    documentation: str = Field(description="Implementation documentation")

class CodeGenerationSchema(BaseModel):
    params: CodeGenerationInput

@tool(args_schema=CodeGenerationSchema)
def generate_code(params: CodeGenerationInput) -> CodeGenerationOutput:
    """Generates implementation code for tools."""
    print("\n💻 Starting Code Generation...")
    
    try:
        # Ensure we have valid input
        if isinstance(params, dict):
            params = CodeGenerationInput(**params)
        elif not isinstance(params, CodeGenerationInput):
            raise ValueError("Invalid input parameters")
        
        llm = ChatOpenAI(
            model="gpt-4o",
            temperature=0.7
        )
        
        # Generate tool implementation
        tool_prompt = f"""Generate a Python tool implementation for a LangChain tool with these specifications:

        Name: {params.tool_name or "WeatherAPI"}
        Description: {params.description}
        
        The tool should follow this exact structure (like flights_finder.py):
        1. Import statements at the top
        2. Input schema class using Pydantic BaseModel with proper type hints
        3. @tool decorator with args_schema
        4. Main tool function with comprehensive error handling
        5. Return appropriate typed response
        
        Requirements:
        - Use modern Python with type hints
        - Include proper error handling with try/except
        - Follow the exact same pattern as this example:
        
        ```python
        import os
        from typing import Optional
        from langchain.pydantic_v1 import BaseModel, Field
        from langchain_core.tools import tool
        
        class ToolInput(BaseModel):
            param1: str = Field(description='Description of param1')
            param2: Optional[int] = Field(description='Description of param2')
        
        class ToolInputSchema(BaseModel):
            params: ToolInput
        
        @tool(args_schema=ToolInputSchema)
        def tool_name(params: ToolInput):
            '''
            Tool description.
            
            Returns:
                type: Description of return value
            '''
            try:
                # Implementation
                result = do_something(params)
                return result
            except Exception as e:
                print(f"Error in tool_name: {{str(e)}}")
                return None
        ```
        
        For this specific tool, implement:
        1. Proper input schema for city name
        2. API call to weather.gov
        3. Error handling for API failures
        4. Return weather data in a structured format
        
        Generate the complete implementation following this exact pattern.
        """

        tool_messages = [
            SystemMessage(content="You are an expert Python developer specializing in LangChain tool development."),
            HumanMessage(content=tool_prompt)
        ]
        
        tool_response = llm.invoke(tool_messages)
        # Extract only the code portion from the response using regex
        pattern = r"```python\s*(.*?)\s*```"
        match = re.search(pattern, tool_response.content, re.DOTALL)
        if match:
            code = match.group(1).strip()
        else:
            code = tool_response.content.strip()
        
        # Return the generated code and description
        return CodeGenerationOutput(
            code=code,
            documentation=params.description
        )
        
    except Exception as e:
        print(f"Error during code generation: {str(e)}")
        return CodeGenerationOutput(
            code="",
            documentation=f"Error generating code: {str(e)}"
        )