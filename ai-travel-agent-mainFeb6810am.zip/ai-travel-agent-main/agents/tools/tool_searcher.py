import os
from typing import Dict, List
from pydantic import BaseModel, Field
from langchain_core.tools import tool
from langchain_openai import OpenAIEmbeddings
import numpy as np

# Constants
EMBEDDING_MODEL = "text-embedding-ada-002"
SIMILARITY_THRESHOLD = 0.7

class ToolSearchInput(BaseModel):
    """Input schema for tool search."""
    analysis: str = Field(description="The requirements analysis")

class ToolSearchOutput(BaseModel):
    """Output schema for tool search."""
    matching_tools: Dict[str, str] = Field(description="Matching tools and their relevance")
    recommendations: str = Field(description="Tool integration recommendations")
    similarity_scores: Dict[str, float] = Field(description="Similarity scores for matched tools")

class ToolSearchSchema(BaseModel):
    params: ToolSearchInput

class SemanticToolSearch:
    """Semantic search for finding similar tools."""
    
    def __init__(self):
        try:
            if not os.getenv("OPENAI_API_KEY"):
                raise ValueError("OPENAI_API_KEY environment variable is not set")
            self.embeddings = OpenAIEmbeddings(
                model=EMBEDDING_MODEL
            )
            self._cache: Dict[str, np.ndarray] = {}
        except Exception as e:
            print(f"Error initializing embeddings: {str(e)}")
            raise
    
    def _get_embedding(self, text: str) -> np.ndarray:
        """Get embedding for text, using cache if available."""
        try:
            if text not in self._cache:
                self._cache[text] = np.array(self.embeddings.embed_query(text))
            return self._cache[text]
        except Exception as e:
            print(f"Error getting embedding: {str(e)}")
            raise
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors."""
        try:
            return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))
        except Exception as e:
            print(f"Error calculating similarity: {str(e)}")
            return 0.0
    
    def search(self, query: str, tools: Dict[str, Dict]) -> Dict[str, tuple[str, float]]:
        """Search for tools similar to the query."""
        try:
            if not tools:
                return {}
            
            query_embedding = self._get_embedding(query)
            results = {}
            
            for tool_name, tool_info in tools.items():
                # Combine tool name and description for better matching
                tool_text = f"{tool_name} {tool_info.get('description', '')}"
                tool_embedding = self._get_embedding(tool_text)
                
                similarity = self._cosine_similarity(query_embedding, tool_embedding)
                
                if similarity >= SIMILARITY_THRESHOLD:
                    results[tool_name] = (tool_info.get('description', ''), similarity)
            
            return dict(sorted(
                results.items(),
                key=lambda x: x[1][1],
                reverse=True
            ))
        except Exception as e:
            print(f"Error in semantic search: {str(e)}")
            return {}

@tool(args_schema=ToolSearchSchema)
def search_tools(params: ToolSearchInput) -> ToolSearchOutput:
    """Searches existing tools using semantic search with embeddings."""
    print("\n🔎 Starting Tool Search with Semantic Matching...")
    
    try:
        # Initialize semantic search
        searcher = SemanticToolSearch()
        
        # Read available tools from registry
        try:
            import json
            with open(os.path.join(os.path.dirname(__file__), '../registry/tools.json'), 'r', encoding='utf-8') as f:
                available_tools = json.load(f)
        except Exception as e:
            print(f"Warning: Could not load tools from registry: {e}")
            available_tools = {}
        
        # Perform semantic search
        matching_results = searcher.search(params.analysis, available_tools)
        
        # Prepare output
        matching_tools = {name: info[0] for name, info in matching_results.items()}
        similarity_scores = {name: info[1] for name, info in matching_results.items()}
        
        recommendations = f"Found {len(matching_tools)} semantically matching tools."
        if matching_tools:
            recommendations += "\nRecommended tools (with similarity scores):\n"
            for name, score in similarity_scores.items():
                recommendations += f"- {name}: {score:.3f}\n"
        
        print("✅ Semantic Tool Search completed")
        print(f"Found {len(matching_tools)} matches")
        
        return ToolSearchOutput(
            matching_tools=matching_tools,
            recommendations=recommendations,
            similarity_scores=similarity_scores
        )
        
    except Exception as e:
        error_msg = f"Error during semantic tool search: {str(e)}"
        print(f"❌ {error_msg}")
        return ToolSearchOutput(
            matching_tools={},
            recommendations=f"Search failed: {error_msg}",
            similarity_scores={}
        )