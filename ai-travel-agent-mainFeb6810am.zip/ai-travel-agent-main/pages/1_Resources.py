import streamlit as st
from agents.registry_manager import RegistryManager

def initialize_registry():
    if 'registry' not in st.session_state:
        st.session_state.registry = RegistryManager()

def render_custom_css():
    st.markdown("""
        <style>
        .tool-list {
            list-style-type: none;
            padding-left: 0;
            margin-top: 0.5rem;
        }
        .tool-list li {
            margin-bottom: 0.25rem;
            padding-left: 1.5em;
            text-indent: -1.5em;
        }
        .tool-list li:before {
            content: "🔧";
            padding-right: 0.5em;
        }
        </style>
    """, unsafe_allow_html=True)

def render_agent_tools(tools):
    """Helper function to render tools list consistently."""
    if not tools:
        return
        
    st.markdown('**Supported Tools:**')
    for tool in tools:
        # Handle different tool formats
        if isinstance(tool, dict):
            # Case 1: Tool is a dictionary with full details
            tool_name = tool.get('name', 'Unknown Tool')
            tool_desc = tool.get('description', '')
            if tool_desc:
                st.markdown(f"- 🔧 **{tool_name}**: {tool_desc}")
            else:
                st.markdown(f"- 🔧 {tool_name}")
        elif isinstance(tool, str):
            # Case 2: Tool is just a string name
            st.markdown(f"- 🔧 {tool}")

def render_resources_page():
    st.title('🗄️ Resources')
    st.markdown('### Browse all available Agents and Tools')
    
    # Create tabs for Agents and Tools
    agents_tab, tools_tab = st.tabs(['Agents', 'Tools'])
    
    with agents_tab:
        agents = st.session_state.registry.list_agents()
        if not agents:
            st.info('No agents have been created yet.')
        else:
            # Process agents in pairs
            agent_items = list(agents.items())
            for i in range(0, len(agent_items), 2):
                col1, col2 = st.columns(2)
                
                # First agent in the pair
                with col1:
                    agent_id, agent_data = agent_items[i]
                    with st.expander(f'🤖 {agent_id}'):
                        st.markdown(f'**Description:** {agent_data.get("agent_description", "No description available")}')
                        st.markdown(f'**Type:** {agent_data.get("agent_chain_type", "Not specified")}')
                        render_agent_tools(agent_data.get('tools', []))
                
                # Second agent in the pair (if available)
                if i + 1 < len(agent_items):
                    with col2:
                        agent_id, agent_data = agent_items[i + 1]
                        with st.expander(f'🤖 {agent_id}'):
                            st.markdown(f'**Description:** {agent_data.get("agent_description", "No description available")}')
                            st.markdown(f'**Type:** {agent_data.get("agent_chain_type", "Not specified")}')
                            render_agent_tools(agent_data.get('tools', []))
    
    with tools_tab:
        tools = st.session_state.registry.list_tools()
        if not tools:
            st.info('No tools have been created yet.')
        else:
            # Process tools in pairs
            tool_items = list(tools.items())
            for i in range(0, len(tool_items), 2):
                col1, col2 = st.columns(2)
                
                # First tool in the pair
                with col1:
                    tool_id, tool_data = tool_items[i]
                    with st.expander(f'🔧 {tool_id}'):
                        st.markdown(f'**Description:** {tool_data.get("description", "No description available")}')
                
                # Second tool in the pair (if available)
                if i + 1 < len(tool_items):
                    with col2:
                        tool_id, tool_data = tool_items[i + 1]
                        with st.expander(f'🔧 {tool_id}'):
                            st.markdown(f'**Description:** {tool_data.get("description", "No description available")}')

def main():
    render_custom_css()
    initialize_registry()
    render_resources_page()

if __name__ == '__main__':
    main()