import os
import json
import uuid
from typing import Dict, Any, List, TypedDict, Annotated
import operator
import streamlit as st
from langchain_core.messages import HumanMessage, SystemMessage, AnyMessage, ToolMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from agents.registry_manager import RegistryManager

# Constants
OPENAI_MODEL = "gpt-4o"

class DynamicAgentState(TypedDict):
    """State for the dynamic agent workflow."""
    messages: Annotated[list[AnyMessage], operator.add]

class DynamicAgent:
    def __init__(self, agent_config: dict, tools_config: dict):
        self.agent_config = agent_config
        self.tools = {}
        self.setup_tools(tools_config)
        
        # Initialize LLM with tools
        self._tools_llm = ChatOpenAI(model=agent_config.get('model_name', OPENAI_MODEL)).bind_tools(list(self.tools.values()))
        
        # Initialize state graph
        builder = StateGraph(DynamicAgentState)
        
        # Add nodes
        builder.add_node("call_tools_llm", self.call_tools_llm)
        builder.add_node("invoke_tools", self.invoke_tools)
        
        # Set entry point
        builder.set_entry_point("call_tools_llm")
        
        # Add edges
        builder.add_conditional_edges(
            "call_tools_llm",
            self.should_continue,
            {
                "more_tools": "invoke_tools",
                "end": END
            }
        )
        builder.add_edge("invoke_tools", "call_tools_llm")
        
        # Compile graph
        memory = MemorySaver()
        self.graph = builder.compile(checkpointer=memory)

    def setup_tools(self, tools_config: dict):
        """Set up tools from the configuration."""
        try:
            for tool_name in self.agent_config.get('tools', []):
                if isinstance(tool_name, dict):
                    tool_name = tool_name.get('name')
                if tool_name in tools_config:
                    tool_code = tools_config[tool_name].get('code', '')
                    # Create a temporary namespace for the tool
                    tool_namespace = {}
                    try:
                        # Execute the tool code in the namespace
                        exec(tool_code, tool_namespace)
                        # The tool function should be the last item in the namespace
                        tool_function = None
                        for item in tool_namespace.values():
                            if callable(item) and hasattr(item, 'name'):
                                tool_function = item
                                break
                        if tool_function:
                            self.tools[tool_name] = tool_function
                    except Exception as e:
                        print(f"Error setting up tool {tool_name}: {str(e)}")
        except Exception as e:
            print(f"Error in setup_tools: {str(e)}")

    @staticmethod
    def should_continue(state: DynamicAgentState) -> str:
        """Determine if we should continue processing or end."""
        last_message = state['messages'][-1]
        if hasattr(last_message, 'tool_calls') and last_message.tool_calls:
            return "more_tools"
        return "end"

    def call_tools_llm(self, state: DynamicAgentState) -> Dict[str, Any]:
        """Process messages and determine next actions."""
        messages = state['messages']
        
        # Add system prompt if not present
        if not messages or not any(isinstance(m, SystemMessage) for m in messages):
            messages = [SystemMessage(content=self.agent_config.get('agent_prompt', ''))] + messages
        
        try:
            response = self._tools_llm.invoke(messages)
            return {'messages': [response]}
        except Exception as e:
            print(f"Error in LLM call: {str(e)}")
            return {'messages': [HumanMessage(content=f"Error: {str(e)}")]}

    def invoke_tools(self, state: DynamicAgentState) -> Dict[str, Any]:
        """Execute tool calls and process results."""
        tool_calls = state['messages'][-1].tool_calls
        results = []
        
        for t in tool_calls:
            print(f"Calling tool: {t['name']}")
            
            if t['name'] not in self.tools:
                error_msg = f"Invalid tool name: {t['name']}"
                print(error_msg)
                results.append(ToolMessage(tool_call_id=t['id'], name=t['name'], content=error_msg))
                continue
                
            try:
                # Execute tool
                result = self.tools[t['name']].invoke(t['args'])
                results.append(ToolMessage(tool_call_id=t['id'], name=t['name'], content=str(result)))
            except Exception as e:
                error_msg = f"Error in {t['name']}: {str(e)}"
                print(error_msg)
                results.append(ToolMessage(tool_call_id=t['id'], name=t['name'], content=error_msg))
        
        return {'messages': results}

def initialize_registry():
    """Initialize the registry and session state."""
    if 'registry' not in st.session_state:
        st.session_state.registry = RegistryManager()
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    if 'current_agent' not in st.session_state:
        st.session_state.current_agent = None
    if 'thread_id' not in st.session_state:
        st.session_state.thread_id = str(uuid.uuid4())

def render_agent_details(agent_data: dict):
    """Render agent details in an expander."""
    with st.expander('Agent Details'):
        st.markdown(f"**Description:** {agent_data.get('agent_description', 'No description available')}")
        st.markdown(f"**Model:** {agent_data.get('model_name', 'Not specified')}")
        st.markdown(f"**Memory Type:** {agent_data.get('memory_type', 'Not specified')}")
        st.markdown("**Tools:**")
        for tool in agent_data.get('tools', []):
            if isinstance(tool, dict):
                st.markdown(f"- {tool.get('name', 'Unknown tool')}")
            else:
                st.markdown(f"- {tool}")

def process_message(agent: DynamicAgent, message: str):
    """Process a message using the agent and update chat history."""
    try:
        messages = [HumanMessage(content=message)]
        
        # Create configuration with thread_id
        config = {
            'configurable': {
                'thread_id': st.session_state.thread_id,
                'checkpoint_ns': 'playground',
                'checkpoint_id': str(uuid.uuid4())
            }
        }
        
        result = agent.graph.invoke({'messages': messages}, config=config)
        
        # Add user message to chat history
        st.session_state.chat_history.append({
            'role': 'user',
            'content': message
        })
        
        # Add assistant response to chat history
        st.session_state.chat_history.append({
            'role': 'assistant',
            'content': result['messages'][-1].content
        })
        
        return result['messages'][-1].content
    except Exception as e:
        error_msg = f"Error processing message: {str(e)}"
        print(error_msg)
        return error_msg

def render_chat_interface():
    """Render the chat interface."""
    # Display chat history
    for message in st.session_state.chat_history:
        with st.chat_message(message['role']):
            st.markdown(message['content'])
    
    # Chat input
    if prompt := st.chat_input('Type your message here...'):
        if st.session_state.current_agent:
            response = process_message(st.session_state.current_agent, prompt)
            st.rerun()
        else:
            st.error('Please select an agent first.')

def render_playground_page():
    """Main function to render the playground page."""
    st.title('🎮 Agent Playground')
    st.markdown('### Test and interact with your generated agents')
    
    # Initialize registry and get available agents
    agents = st.session_state.registry.list_agents()
    tools = st.session_state.registry.list_tools()
    
    if not agents:
        st.info('No agents available. Please create an agent first.')
        return
    
    # Agent selection
    selected_agent = st.selectbox(
        'Select an Agent to interact with',
        options=list(agents.keys()),
        format_func=lambda x: f"🤖 {x}"
    )
    
    if selected_agent:
        agent_data = agents[selected_agent]
        render_agent_details(agent_data)
        
        # Initialize the agent if it's a new selection
        if 'current_agent' not in st.session_state or \
           st.session_state.current_agent is None or \
           st.session_state.current_agent.agent_config.get('agent_name') != selected_agent:
            st.session_state.current_agent = DynamicAgent(agent_data, tools)
            st.session_state.chat_history = []  # Clear chat history for new agent
            st.session_state.thread_id = str(uuid.uuid4())  # Generate new thread_id for new agent
        
        render_chat_interface()

def main():
    initialize_registry()
    render_playground_page()

if __name__ == '__main__':
    main()