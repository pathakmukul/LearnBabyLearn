import streamlit as st

def render_custom_css():
    st.markdown(
        '''
        <style>
        .doc-title {
            font-size: 2.5em;
            color: #333;
            text-align: center;
            margin-bottom: 1em;
            font-weight: bold;
        }
        .section-title {
            font-size: 1.8em;
            color: #2c3e50;
            margin-top: 1em;
            margin-bottom: 0.5em;
        }
        .subsection-title {
            font-size: 1.4em;
            color: #34495e;
            margin-top: 0.8em;
            margin-bottom: 0.4em;
        }
        .code-block {
            background-color: #f8f9fa;
            padding: 1em;
            border-radius: 5px;
            margin: 1em 0;
        }
        .highlight {
            background-color: #e8f4f8;
            padding: 0.2em 0.4em;
            border-radius: 3px;
        }
        </style>
        ''', unsafe_allow_html=True
    )

def render_overview():
    st.markdown('<div class="doc-title">📚 Project Documentation</div>', unsafe_allow_html=True)
    
    st.markdown("""
    Welcome to our AI Agent Generator! This powerful system helps you create custom AI agents tailored to your specific needs. 
    Built with cutting-edge AI technology, it makes creating and managing AI agents simple and intuitive.
    
    The platform offers four main features:
    - **Agent Creation**: Design and configure your custom AI agents
    - **Resources**: Access guides and helpful documentation
    - **Playground**: Test and interact with your agents
    - **API Access**: Integrate agents into your applications
    """)

def render_agent_creation():
    st.markdown('<div class="section-title">🤖 Creating Agents</div>', unsafe_allow_html=True)
    
    st.markdown('<div class="subsection-title">Agent Creation Process</div>', unsafe_allow_html=True)
    st.markdown("""
    Our AI Agent Generator follows an intelligent workflow to create your custom agents:
    
    1. **Requirements Understanding**
       - Provide your agent's name and detailed description
       - The system analyzes your requirements automatically
       - Identifies needed capabilities and functionalities
    
    2. **Intelligent Tool Integration**
       - Automatically finds and integrates relevant tools
       - Uses advanced semantic matching to find the best tools for your needs
       - Creates new specialized tools when needed
    
    3. **Smart Workflow Management**
       - Manages conversation context intelligently
       - Handles complex multi-step interactions
       - Ensures consistent and reliable responses
    """)
    
    st.markdown('<div class="subsection-title">Creating Your Agent</div>', unsafe_allow_html=True)
    with st.expander("Configuration Options", expanded=True):
        st.markdown("""
        To create your custom agent, you'll need to specify:
        
        - **Agent Name** (required)
          - Choose a unique, memorable name
          - This will be your agent's identifier
        
        - **Agent Description** (required)
          - Describe what you want your agent to do
          - Be specific about desired capabilities
          - Include any special requirements or preferences
        
        - **AI Model**
          - Advanced: Better for complex tasks, more creative responses
          - Standard: Faster, great for simple tasks
        
        - **Memory Configuration**
          - Simple: Best for straightforward conversations
          - Conversation: Enhanced context awareness
          - Summary: Efficient handling of long interactions
        
        - **Interaction Style**
          - Standard: Direct question-answer format
          - Structured: Enhanced formatting and organization of responses
        """)

def render_resources():
    st.markdown('<div class="section-title">📖 Resources Page</div>', unsafe_allow_html=True)
    st.markdown("""
    The Resources page provides comprehensive documentation and references:
    
    - **Technical Documentation**
      - Detailed API specifications
      - Tool development guidelines
      - Agent configuration options
    
    - **References**
      - LangGraph documentation
      - LangChain integration details
      - Best practices and examples
    
    - **Troubleshooting**
      - Common issues and solutions
      - Performance optimization tips
      - Debugging strategies
    """)

def render_playground():
    st.markdown('<div class="section-title">🎮 Playground Page</div>', unsafe_allow_html=True)
    st.markdown("""
    The Playground provides an interactive environment to test your agents:
    
    - **Agent Selection**
      - Choose from your generated agents
      - View agent configuration and capabilities
    
    - **Interactive Testing**
      - Send messages to your agent
      - Observe tool usage and reasoning
      - Review conversation history
    
    - **Real-time Feedback**
      - Monitor agent performance
      - Debug tool execution
      - Validate agent behavior
    """)

def render_api():
    st.markdown('<div class="section-title">🔌 API Usage</div>', unsafe_allow_html=True)
    
    st.markdown("The system exposes a REST API for programmatic integration:")
    
    with st.expander("Available Endpoints", expanded=True):
        st.markdown("""
        **1. List Available Agents**
        ```bash
        GET http://localhost:8001/agents
        
        # Example using curl:
        curl http://localhost:8001/agents
        ```
        
        **2. Run Agent**
        ```bash
        POST http://localhost:8001/agents/{agent_name}/run
        Content-Type: application/json
        
        {
            "message": "Your message here"
        }
        
        # Example using curl:
        curl -X POST http://localhost:8001/agents/YourAgentName/run \\
             -H "Content-Type: application/json" \\
             -d '{"message": "Your message here"}'
        ```
        """)
    
    st.markdown("""
    **Response Format**
    ```python
    {
        "response": "Agent's response message",
        # Additional metadata depending on the agent's configuration
    }
    ```
    """)

def render_documentation():
    render_custom_css()
    render_overview()
    render_agent_creation()
    render_resources()
    render_playground()
    render_api()
    
    st.markdown("---")
    st.markdown("""
    """)

def main():
    render_documentation()

if __name__ == '__main__':
    main()
