import os
from typing import Dict, Any, List, TypedDict, Annotated
from enum import Enum
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage, AnyMessage, ToolMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from pydantic import BaseModel
from dotenv import load_dotenv
import operator
from agents.tools.requirements_analyzer import analyze_requirements
from agents.tools.tool_searcher import search_tools
from agents.tools.code_generator import generate_code
import json
import traceback
from agents.registry_manager import RegistryManager

_ = load_dotenv()

class GenticState(TypedDict):
    """State for the Gentic agent workflow."""
    messages: Annotated[list[AnyMessage], operator.add]

GENTIC_SYSTEM_PROMPT = """You are an expert AI agent development assistant specializing in creating LangGraph REACT agents.
Your role is to help analyze requirements and generate LangGraph-based agents with appropriate tools.

CONTEXT:
- We are building agents using the LangGraph framework
- Each agent follows the REACT (Reason+Act) pattern
- Agents use a state machine graph with nodes for reasoning and tool execution
- Tools must be properly typed and documented for LangGraph integration

When analyzing requirements:
1. Identify core agent functionality and capabilities needed
2. Determine what LangGraph-compatible tools would be necessary
3. Consider the agent's state management and graph structure
4. Plan the agent's system prompt and chain type

The tools you create MUST follow this structure:
1. Tool Class with Pydantic models for inputs/outputs
2. @tool decorator with proper typing
3. Comprehensive docstrings
4. Error handling and logging
5. State management integration

You MUST follow this strict workflow in order:

1. FIRST STEP - Requirements Analysis:
   - Use analyze_requirements tool to process the initial requirements
   - Identify needed LangGraph components:
     * Required tools and their interfaces
     * State management approach
     * Graph structure
     * System prompts
   - Wait for results before proceeding

2. SECOND STEP - Tool Search:
   - ONLY after requirements are analyzed, use search_tools
   - Look for existing LangGraph-compatible tools
   - Identify which tools need to be created
   - Consider tool dependencies and interactions

3. FINAL STEP - Code Generation:
   - ONLY after tool search is complete, use generate_code
   - Generate the complete LangGraph agent implementation including:
     * All required tools with proper typing
     * State management class
     * Graph structure setup
     * System prompts
     * Tool registration
   - Include all necessary imports and dependencies
   - Ensure proper error handling and logging

IMPORTANT:
- Each tool must be LangGraph-compatible
- Tools must handle state transitions properly
- System prompts must guide the agent's behavior
- Generated code must follow LangGraph best practices
- The workflow ends only after full agent implementation

Example Tool Structure:
```python
from typing import TypedDict, List
from pydantic import BaseModel
from langchain_core.tools import tool

class ToolInput(BaseModel):
    param1: str
    param2: List[str]

class ToolOutput(TypedDict):
    result: str
    state_update: dict

@tool
def example_tool(params: ToolInput) -> ToolOutput:
    \"\"\"Tool description and usage.\"\"\"
    # Implementation
    return {"result": "...", "state_update": {...}}
```

Provide clear explanations and recommendations in your responses.
"""

class GenticAgent:
    def __init__(self):
        self.llm = ChatOpenAI(
            model="gpt-4o",
            temperature=0,
            api_key=os.getenv('OPENAI_API_KEY')
        )
        self._tools = {
            'analyze_requirements': analyze_requirements,
            'search_tools': search_tools,
            'generate_code': generate_code
        }
        self._tools_llm = ChatOpenAI(model='gpt-4o').bind_tools(list(self._tools.values()))
        self.registry = RegistryManager()
        
        # Initialize state graph
        builder = StateGraph(GenticState)
        
        # Add nodes
        builder.add_node("call_tools_llm", self.call_tools_llm)
        builder.add_node("invoke_tools", self.invoke_tools)
        
        # Set entry point
        builder.set_entry_point("call_tools_llm")
        
        # Add conditional edges
        builder.add_conditional_edges(
            "call_tools_llm",
            self.should_continue,
            {
                "more_tools": "invoke_tools",
                "end": END
            }
        )
        
        # Add edge from tools back to agent only if more tools needed
        builder.add_conditional_edges(
            "invoke_tools",
            self.should_continue,
            {
                "more_tools": "call_tools_llm",
                "end": END
            }
        )
        
        # Configure memory saver
        memory = MemorySaver()
        self.graph = builder.compile(checkpointer=memory)

    @staticmethod
    def should_continue(state: GenticState) -> str:
        """Determine next action based on the last message."""
        last_message = state['messages'][-1]
        
        # If we have a tool response from generate_code or analyze_requirements with save confirmation, end
        if isinstance(last_message, ToolMessage):
            if last_message.name == 'generate_code':
                return 'end'
            if last_message.name == 'analyze_requirements' and 'generated and saved successfully' in last_message.content:
                return 'end'
            
        # If we have tool calls, continue with tools
        if hasattr(last_message, 'tool_calls') and last_message.tool_calls:
            return 'more_tools'
            
        # Otherwise end
        return 'end'

    def call_tools_llm(self, state: GenticState) -> Dict[str, Any]:
        """Process messages and determine next actions."""
        messages = state['messages']
        
        # Add system prompt if not present
        if not messages or not any(isinstance(m, SystemMessage) for m in messages):
            messages = [SystemMessage(content=GENTIC_SYSTEM_PROMPT)] + messages
        
        try:
            # Get LLM response
            response = self._tools_llm.invoke(messages)
            print("response gentic:::::::", response)
            return {'messages': [response]}
        except Exception as e:
            print(f"\n❌ Error in LLM call: {str(e)}")
            traceback.print_exc()
            return {'messages': [AIMessage(content=f"Error: {str(e)}")]}

    def invoke_tools(self, state: GenticState) -> Dict[str, Any]:
        """Execute tool calls and process results."""
        tool_calls = state['messages'][-1].tool_calls
        results = []
        agent_config = None
        
        for t in tool_calls:
            print(f'\n🔄 Calling tool: {t["name"]}')
            
            if not t['name'] in self._tools:
                error_msg = 'Invalid tool name, please retry'
                print(f"\n❌ {error_msg}")
                results.append(ToolMessage(tool_call_id=t['id'], name=t['name'], content=error_msg))
                continue
                
            try:
                # Prepare tool arguments
                args = t['args']
                if isinstance(args, str):
                    args = json.loads(args)
                
                # Execute tool
                print(f"\n⚙️ Executing {t['name']}...")
                result = self._tools[t['name']].invoke(args)
                print(f"✅ {t['name']} execution completed")
                
                if t['name'] == 'analyze_requirements':
                    # Store initial requirements
                    if isinstance(args, dict):
                        if 'params' in args:
                            initial_args = args['params']
                        else:
                            initial_args = args
                        
                        print(f"\n📝 Processing requirements for agent: {initial_args.get('agent_name', '')}")
                        
                        # Initialize agent config
                        agent_config = {
                            'agent_name': initial_args.get('agent_name', ''),
                            'agent_description': initial_args.get('description', ''),
                            'agent_prompt': '',  # Initialize empty prompt
                            'tools': [],  # Initialize empty tools list
                            'memory_type': initial_args.get('memory_type', 'buffer'),
                            'model_name': initial_args.get('model_name', 'gpt-4o'),
                            'agent_chain_type': initial_args.get('agent_type', 'ZERO_SHOT_REACT_DESCRIPTION')
                        }
                    
                    # Process analysis results
                    result_dict = result.dict() if hasattr(result, 'dict') else result
                    print(f"\n📊 Analysis Results:")
                    print(f"- System Prompt: {len(result_dict.get('system_prompt', ''))} chars")
                    print(f"- Tools Required: {len(result_dict.get('tools', []))}")
                    print("\nSystem Prompt:")
                    print(result_dict.get('system_prompt', ''))
                    print("\nRequired Tools:")
                    
                    # Update agent config with analyzed results
                    agent_config['agent_prompt'] = result_dict.get('system_prompt', '')
                    agent_config['tools'] = result_dict.get('tools', [])
                    agent_config['agent_chain_type'] = 'REACT'  # Set to REACT as per requirements
                    
                    # Create initial tool entries in tools.json
                    for tool in result_dict.get('tools', []):
                        tool_name = tool.get('name', '')
                        print(f"\n🛠️ Tool: {tool_name}")
                        print(f"Description: {tool.get('description', '')}")
                        print(f"Input Schema: {json.dumps(tool.get('input_schema', {}), indent=2)}")
                        print(f"Output Schema: {json.dumps(tool.get('output_schema', {}), indent=2)}")
                        print(f"Implementation Notes: {tool.get('implementation_notes', '')}")
                        
                        # Create tool entry in registry
                        tool_entry = {
                            'name': tool_name,
                            'description': tool.get('description', ''),
                            'code': '',  # Will be populated by code generator
                            'identifier': tool_name,
                            'dependencies': ['langchain_core', 'requests'],
                            'version': '1.0.0',
                            'category': 'api',
                            'test_cases': [],
                            'metadata': {}
                        }
                        self.registry.save_tool(tool_name, tool_entry)
                        
                        # Generate code for the tool
                        code_gen_args = {
                            'params': {  # Add params wrapper to match schema
                                'agent_name': agent_config['agent_name'],
                                'tool_name': tool_name,
                                'description': tool.get('description', ''),
                                'model_name': agent_config['model_name'],
                                'memory_type': agent_config['memory_type'],
                                'agent_type': agent_config['agent_chain_type']
                            }
                        }
                        
                        try:
                            code_result = self._tools['generate_code'].invoke(code_gen_args)
                            if hasattr(code_result, 'code') and code_result.code:
                                # Update tool entry with generated code
                                tool_entry['code'] = code_result.code
                                self.registry.save_tool(tool_name, tool_entry)
                                print(f"✅ Generated and saved code for tool: {tool_name}")
                        except Exception as e:
                            print(f"❌ Error generating code for {tool_name}: {str(e)}")
                            continue  # Skip to next tool on error
                    
                    # Save final agent config
                    if agent_config:
                        self.registry.save_agent(agent_config['agent_name'], agent_config)
                        print(f"\n✅ Saved agent configuration with prompt and tools")
                        # Add completion message to results to trigger end
                        results.append(ToolMessage(
                            tool_call_id=t['id'],
                            name=t['name'],
                            content=f"Agent '{agent_config['agent_name']}' generated and saved successfully"
                        ))
                        return {'messages': results}  # Return immediately after saving
                    
                elif t['name'] == 'search_tools':
                    print("\n🔍 Found existing tools:")
                    if hasattr(result, 'tools'):
                        for tool in result.tools:
                            print(f"\n📦 Tool: {tool.name}")
                            print(f"Description: {tool.description}")
                            print(f"Has Implementation: {'Yes' if tool.has_implementation else 'No'}")
                    else:
                        print("No existing tools found")
                
                # Add tool response
                results.append(ToolMessage(tool_call_id=t['id'], name=t['name'], content=str(result)))
                
            except Exception as e:
                error_msg = f"Error in {t['name']}: {str(e)}"
                print(f'\n❌ {error_msg}')
                traceback.print_exc()
                results.append(ToolMessage(tool_call_id=t['id'], name=t['name'], content=error_msg))
                continue
        
        return {'messages': results}

    def save_agent(self, state: GenticState) -> Dict[str, Any]:
        """Final step to save the agent."""
        try:
            # Get the last message to extract agent name
            last_message = state['messages'][-1]
            
            # Only save if we have a completion message
            if isinstance(last_message, AIMessage):
                if "generated and saved successfully" in last_message.content:
                    agent_name = last_message.content.split('"')[1]
                    print(f"\n✅ Agent {agent_name} saved successfully")
                    return {'messages': [AIMessage(content=f"Agent {agent_name} ready to use!")]}
            
            # For other cases, just end without saving
            return {'messages': [AIMessage(content="Agent generation completed.")]}
                
        except Exception as e:
            print(f'\n❌ Error in final step: {str(e)}')
            traceback.print_exc()
            return {'messages': [AIMessage(content=f"Error in final step: {str(e)}")]}