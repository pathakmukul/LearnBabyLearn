import os
from typing import Dict, List
from pydantic import BaseModel, Field
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
import json

class RequirementsAnalysisInput(BaseModel):
    """Input schema for requirements analysis tool."""
    description: str = Field(description="The user's requirements description")
    agent_name: str = Field(description="Name of the agent")
    model_name: str = Field(description="Model to use (e.g. gpt-4o)")
    memory_type: str = Field(description="Type of memory to use")
    agent_type: str = Field(description="Type of agent chain")

class ToolSpec(BaseModel):
    """Specification for a tool."""
    name: str = Field(description="Name of the tool")
    description: str = Field(description="Description of what the tool does")
    input_schema: Dict = Field(description="Input parameters schema")
    output_schema: Dict = Field(description="Output schema")
    implementation_notes: str = Field(description="Notes on how to implement the tool")

class RequirementsAnalysisOutput(BaseModel):
    """Output schema for requirements analysis tool."""
    agent_name: str = Field(description="Name of the agent")
    description: str = Field(description="Description of the agent")
    system_prompt: str = Field(description="System prompt for the agent")
    tools: List[ToolSpec] = Field(description="Required tools specifications")

class RequirementsAnalysisSchema(BaseModel):
    params: RequirementsAnalysisInput

ANALYSIS_SYSTEM_PROMPT = """You are an expert in analyzing requirements for AI agents.
Your task is to analyze the requirements and determine:
1. A clear system prompt that will guide the agent's behavior
2. The necessary tools the agent will need to function

IMPORTANT: You must respond with ONLY a JSON object in this exact format:
{
    "agent_name": "name of the agent",
    "description": "original description",
    "system_prompt": "a detailed system prompt that will guide the agent's behavior",
    "tools": [
        {
            "name": "tool_name",
            "description": "what the tool does",
            "input_schema": {
                "field_name": "field type and description"
            },
            "output_schema": {
                "field_name": "field type and description"
            },
            "implementation_notes": "notes on how to implement the tool"
        }
    ]
}

Focus on:
1. Creating a clear, focused system prompt
2. Identifying only the necessary tools with their interfaces
3. Ensuring tools have clear input/output schemas
4. Providing implementation notes for each tool

The response must be valid JSON that can be parsed by json.loads().
Do not include any other text or markdown formatting.
"""

@tool(args_schema=RequirementsAnalysisSchema)
def analyze_requirements(params: RequirementsAnalysisInput) -> Dict:
    """Analyzes requirements and determines needed components for an AI agent."""
    print("\n🔍 Starting Requirements Analysis...")
    
    # Ensure we have valid input
    try:
        if isinstance(params, dict):
            if 'params' in params:
                params = params['params']
            params = RequirementsAnalysisInput(**params)
        elif not isinstance(params, RequirementsAnalysisInput):
            raise ValueError(f"Invalid input parameters type: {type(params)}")
        
        print(f"Analyzing requirements for agent: {params.agent_name}")
    except Exception as e:
        print(f"Error validating input parameters: {str(e)}")
        raise
    
    llm = ChatOpenAI(
        model="gpt-4o",
        temperature=0.1
    )
    
    prompt = f"""Based on these requirements, provide an agent specification:

Agent Name: {params.agent_name}
Description: {params.description}

RESPOND WITH ONLY A JSON OBJECT IN THIS EXACT FORMAT:
{{
    "agent_name": "{params.agent_name}",
    "description": "{params.description}",
    "system_prompt": "A detailed system prompt that will guide the agent's behavior",
    "tools": [
        {{
            "name": "tool_name",
            "description": "what the tool does",
            "input_schema": {{
                "field_name": "field type and description"
            }},
            "output_schema": {{
                "field_name": "field type and description"
            }},
            "implementation_notes": "notes on how to implement the tool"
        }}
    ]
}}

IMPORTANT:
1. The response must be a valid JSON object
2. Do not include any markdown formatting or additional text
3. Replace all placeholders with actual values
4. Ensure tool specifications match the requirements"""

    messages = [
        SystemMessage(content=ANALYSIS_SYSTEM_PROMPT),
        HumanMessage(content=prompt)
    ]
    
    try:
        response = llm.invoke(messages)
        print("Got response from LLM")
        
        # Clean the response
        content = response.content.strip()
        if content.startswith('```json'):
            content = content.split('```json')[1]
        if content.endswith('```'):
            content = content.rsplit('```', 1)[0]
        content = content.strip()
        
        # Parse response
        try:
            result = json.loads(content)
            print(f"Successfully parsed response")
            
            # Validate required fields
            required_fields = ['agent_name', 'description', 'system_prompt', 'tools']
            missing_fields = [field for field in required_fields if field not in result]
            if missing_fields:
                raise ValueError(f"Response missing required fields: {', '.join(missing_fields)}")
            
            # Convert tools to ToolSpec objects
            tools = []
            for tool in result['tools']:
                try:
                    tool_spec = ToolSpec(**tool)
                    tools.append(tool_spec.dict())
                except Exception as e:
                    print(f"Error converting tool spec: {str(e)}")
                    continue
            
            if not tools:
                raise ValueError("No valid tools found in response")
            
            # Create output
            output = {
                'agent_name': result['agent_name'],
                'description': result['description'],
                'system_prompt': result['system_prompt'],
                'tools': tools
            }
            
            print("✅ Requirements Analysis completed")
            return output
            
        except json.JSONDecodeError as e:
            print(f"JSON Parse Error: {str(e)}")
            print(f"Problematic content: {content}")
            raise
        
    except Exception as e:
        print(f"Error in requirements analysis: {str(e)}")
        traceback.print_exc()
        raise