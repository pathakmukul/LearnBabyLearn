import os
from typing import Dict
from pydantic import BaseModel, Field
from langchain_core.tools import tool

class ToolSearchInput(BaseModel):
    """Input schema for tool search."""
    analysis: str = Field(description="The requirements analysis")

class ToolSearchOutput(BaseModel):
    """Output schema for tool search."""
    matching_tools: Dict[str, str] = Field(description="Matching tools and their relevance")
    recommendations: str = Field(description="Tool integration recommendations")

class ToolSearchSchema(BaseModel):
    params: ToolSearchInput

@tool(args_schema=ToolSearchSchema)
def search_tools(params: ToolSearchInput) -> ToolSearchOutput:
    """Searches existing tools for matches."""
    print("\n🔎 Starting Tool Search...")
    
    # Read available tools from registry
    try:
        import json
        with open(os.path.join(os.path.dirname(__file__), '../registry/tools.json'), 'r') as f:
            available_tools = json.load(f)
    except Exception as e:
        print(f"Warning: Could not load tools from registry: {e}")
        available_tools = {}
    
    # Basic keyword matching
    matching = {}
    analysis_lower = params.analysis.lower()
    for tool_name, description in available_tools.items():
        if tool_name in analysis_lower or any(keyword in analysis_lower 
            for keyword in tool_name.split('_')):
            matching[tool_name] = description
    
    print("✅ Tool Search completed", matching)
    
    recommendations = "Found {} matching tools.".format(len(matching))
    if matching:
        recommendations += " Recommended tools: " + ", ".join(matching.keys())
    
    return ToolSearchOutput(
        matching_tools=matching,
        recommendations=recommendations
    )