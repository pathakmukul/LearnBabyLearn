import streamlit as st
from agents.registry_manager import RegistryManager

def initialize_registry():
    if 'registry' not in st.session_state:
        st.session_state.registry = RegistryManager()
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []

def render_playground_page():
    st.title('🎮 Agent Playground')
    st.markdown('### Test and interact with your generated agents')
    
    # Initialize registry and get available agents
    agents = st.session_state.registry.list_agents()
    
    if not agents:
        st.info('No agents available. Please create an agent first.')
        return
    
    # Agent selection
    selected_agent = st.selectbox(
        'Select an Agent to interact with',
        options=list(agents.keys()),
        format_func=lambda x: f"🤖 {x}"
    )
    
    if selected_agent:
        agent_data = agents[selected_agent]
        with st.expander('Agent Details'):
            st.markdown(f"**Description:** {agent_data['description']}")
            st.markdown(f"**Model:** {agent_data.get('model_name', 'Not specified')}")
            st.markdown(f"**Memory Type:** {agent_data.get('memory_type', 'Not specified')}")
        
        # Chat interface
        st.markdown('### Chat Interface')
        
        # Display chat history
        for message in st.session_state.chat_history:
            with st.chat_message(message['role']):
                st.markdown(message['content'])
        
        # Chat input
        if prompt := st.chat_input('Type your message here...'):
            # Add user message to chat history
            st.session_state.chat_history.append({
                'role': 'user',
                'content': prompt
            })
            
            # TODO: Implement actual agent interaction here
            # For now, just echo back a placeholder response
            response = f"Agent {selected_agent} received: {prompt}"
            
            # Add assistant response to chat history
            st.session_state.chat_history.append({
                'role': 'assistant',
                'content': response
            })
            
            # Rerun to update the chat display
            st.rerun()

def main():
    initialize_registry()
    render_playground_page()

if __name__ == '__main__':
    main()