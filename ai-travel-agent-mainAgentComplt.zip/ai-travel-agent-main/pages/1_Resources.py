import streamlit as st
from agents.registry_manager import RegistryManager

def initialize_registry():
    if 'registry' not in st.session_state:
        st.session_state.registry = RegistryManager()

def render_resources_page():
    st.title('🗄️ Resources')
    st.markdown('### Browse all available Agents and Tools')
    
    # Create tabs for Agents and Tools
    agents_tab, tools_tab = st.tabs(['Agents', 'Tools'])
    
    with agents_tab:
        agents = st.session_state.registry.list_agents()
        if not agents:
            st.info('No agents have been created yet.')
        else:
            for agent_id, agent_data in agents.items():
                with st.expander(f'🤖 {agent_id}'):
                    st.markdown(f'**Description:** {agent_data["description"]}')
                    st.markdown(f'**Model:** {agent_data.get("model_name", "Not specified")}')
                    st.markdown(f'**Memory Type:** {agent_data.get("memory_type", "Not specified")}')
                    st.markdown(f'**Agent Type:** {agent_data.get("agent_type", "Not specified")}')
                    if st.button('View Code', key=f'view_code_agent_{agent_id}'):
                        st.code(agent_data['code'], language='python')
    
    with tools_tab:
        tools = st.session_state.registry.list_tools()
        if not tools:
            st.info('No tools have been created yet.')
        else:
            for tool_id, tool_data in tools.items():
                with st.expander(f'🔧 {tool_id}'):
                    st.markdown(f'**Description:** {tool_data["description"]}')
                    if st.button('View Code', key=f'view_code_tool_{tool_id}'):
                        st.code(tool_data['code'], language='python')

def main():
    initialize_registry()
    render_resources_page()

if __name__ == '__main__':
    main()